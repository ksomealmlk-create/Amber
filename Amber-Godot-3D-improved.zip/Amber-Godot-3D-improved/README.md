# Amber – The Lost Ember 3D (Godot 4)

This is an actively editable Godot 4 third-person 3D prototype based on the supplied project archive.

## Included
- 11 themed worlds and 110 level slots (10 per world).
- Procedural 3D platforms and routes, world palettes, crystals, spike traps, enemies, gates, and local progress saving.
- Third-person character controller, jumping, camera follow, keyboard controls, touch movement buttons, and touch-drag camera control.
- The original Flutter project and assets are preserved in `legacy_flutter/`.

## Changes in this revision
- Removed the continuous ground slab so platform gaps require jumping.
- Added entrance and exit platforms and a fall recovery zone.
- Added spike-trigger recovery.
- Added simple procedural limb swing and body bob to the player while moving.
- Added mobile touch-drag camera rotation.

## Open and run
1. Install Godot 4.3 or newer.
2. Extract the archive.
3. In Godot Project Manager, import `project.godot` from this folder.
4. Run the project (F6/F5).

## Controls
- WASD / arrow keys: move.
- Space: jump.
- Mouse: rotate camera (desktop).
- Touch buttons: move and jump.
- Drag on the game screen: rotate camera on touch devices.

## Important status
This remains a playable prototype, not a finished commercial game. The player and environment visuals are currently procedural primitive meshes, not fully rigged imported character/environment assets. Level geometry is generated procedurally; the 110 level slots are not 110 individually hand-authored maps. Combat, full boss mechanics, polished animations, audio, settings, and Android export/device testing still need further work.

Android APK export requires a configured Godot Android export template and Android SDK/JDK. This archive has not been run through the Godot editor or exported to APK in this environment.
