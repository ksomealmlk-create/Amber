import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'art.dart';
import 'engine.dart';
import 'level.dart';

class GamePainter extends CustomPainter {
  final GameEngine e;
  final Art a;
  GamePainter(this.e, this.a) : super(repaint: e.frame) {
    final lr = [mkr(11), mkr(16), mkr(21)];
    for (int l = 0; l < 3; l++) {
      for (int i = 0; i < 60; i++) {
        _layers[l].add([i * (60.0 + l * 20), 30 + lr[l]() * (60 + l * 30), 20 + lr[l]() * 30, 15 + lr[l]() * 50]);
      }
    }
    final r = mkr(3);
    for (int i = 0; i < 70; i++) {
      _orbs.add([r() * 2450, 60 + r() * 340, 2 + r() * 3, r() * 6]);
    }
    for (int i = 0; i < 26; i++) {
      _tw.add([r() * 1200, r() * kH * .55, r() * 6]);
    }
    for (int i = 0; i < 40; i++) {
      _motes.add([r() * 1400, r() * kH, r() * 6, .5 + r()]);
    }
  }

  final List<List<List<double>>> _layers = [[], [], []];
  final List<List<double>> _orbs = [], _tw = [], _motes = [];
  final math.Random _rn = math.Random();
  double vw = kW;
  TextPainter? _bossTp;
  String _bossName = '';
  WorldTheme get th => a.th;
  LevelConfig get cfg => e.cfg;

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;

  @override
  void paint(Canvas c, Size size) {
    final s = size.height / kH;
    vw = math.min(kMaxView, size.width / s);
    e.vw = vw;
    c.save();
    c.scale(s);
    c.clipRect(Rect.fromLTWH(0, 0, vw, kH));
    _scene(c);
    c.restore();
  }

  Paint _fill(Color col) => Paint()..color = col;

  void _scene(Canvas c) {
    final t = e.t;
    final cam = e.cam;
    double sx = 0, sy = 0;
    if (e.shake > 0) {
      sx = (_rn.nextDouble() - .5) * e.shake;
      sy = (_rn.nextDouble() - .5) * e.shake;
    }
    c.save();
    c.translate(sx, sy);
    c.drawRect(Rect.fromLTWH(-12, -12, vw + 24, kH + 24), _fill(const Color(0xFF04060C)));
    a.sky.draw(c, cam * .02, 0, vw);
    for (final q in _tw) {
      final al = .25 + .6 * (math.sin(t / 22 + q[2]) * .5 + .5);
      final bx = (q[0] - cam * .03) % vw;
      c.drawRect(Rect.fromLTWH(bx, q[1], 2, 2), _fill(Color.fromRGBO(215, 235, 255, al)));
    }
    a.mt1.draw(c, cam * .08, 0, vw);
    _fog(c, a.fog1, 250, .12, .15);
    a.mt2.draw(c, cam * .18, 0, vw);
    final forest = th.wall == WallStyle.trunks;
    for (int i = 0; i < 3; i++) {
      final f = .2 + i * .25;
      final path = Path();
      for (final q in _layers[i]) {
        final bx = q[0] - cam * f;
        if (bx < -80 || bx > vw + 80) continue;
        if (forest) {
          path.addRect(Rect.fromLTWH(bx, 0, 5 + q[2] * .3, kH));
          path.addOval(Rect.fromCenter(center: Offset(bx + 3, 18 + q[3] * .5), width: 40 + q[1] * .5, height: 26));
        } else {
          path.moveTo(bx, kH);
          path.lineTo(bx + q[2] / 2, kH - q[1] - i * 10 - 40);
          path.lineTo(bx + q[2] + 20, kH);
          path.close();
          path.moveTo(bx, 0);
          path.lineTo(bx + q[3] / 3 + 5, q[3] + 20 + i * 10);
          path.lineTo(bx + q[3] / 1.5 + 10, 0);
          path.close();
        }
      }
      c.drawPath(path, _fill(th.spikes[i]));
    }
    for (final o in _orbs) {
      final bx = ((o[0] - cam * .5) % 2450.0);
      if (bx > vw + 20) continue;
      glow(c, bx, o[1] + math.sin(t / 60 + o[3]) * 10, o[2] * 7, th.orb, .35, add: true);
    }
    c.drawRect(
        Rect.fromLTWH(0, 420, vw, 80),
        Paint()..shader = ui.Gradient.linear(const Offset(0, 420), const Offset(0, kH), const [Color(0x003C96C8), Color(0x4D3C96C8)]));
    a.wall.draw(c, cam * .8, 190, vw);
    for (final ar in a.arches) {
      final x0 = ar.x - cam * .8;
      if (x0 < -100 || x0 > vw + 100) continue;
      final top = 190 + 250 - ar.ah;
      final path = Path()
        ..moveTo(x0 - ar.hw, top)
        ..lineTo(x0 + ar.hw, top)
        ..lineTo(x0 + ar.hw + 90, kFloorY)
        ..lineTo(x0 - ar.hw + 40, kFloorY)
        ..close();
      final al = .10 + math.sin(t / 90 + ar.x) * .03;
      c.drawPath(
          path,
          Paint()
            ..blendMode = BlendMode.plus
            ..shader = ui.Gradient.linear(Offset(x0, top), Offset(x0 + 60, kFloorY), [th.moonGlow.a(al), th.moonGlow.a(0)]));
    }
    _props(c, 0);
    _platforms(c);
    _checkpoints(c);
    _crumbles(c);
    _movers(c);
    _hazards(c);
    _gadgets(c);
    _props(c, 1);
    _chests(c);
    _embers(c);
    _fog(c, a.fog2, 370, .35, .6);
    _goal(c);
    for (final en in e.en) {
      if (en.hp > 0) _enemy(c, en);
    }
    if (e.boss != null) _boss(c);
    if (forest) _vines(c);
    _lighting(c);
    _warmGlows(c);
    if (cfg.world == 10) {
      final dx = e.p.x - cam + 7, dy = e.p.y + 11;
      c.drawRect(
          Rect.fromLTWH(-12, -12, vw + 24, kH + 24),
          Paint()
            ..shader = ui.Gradient.radial(Offset(dx, dy), 190, const [Color(0x00000000), Color(0xF2000000)], const [0.35, 1.0]));
    }
    _fogZones(c);
    _projs(c);
    _player(c);
    for (final q in e.parts) {
      final k = q.l / q.max;
      final col = q.c;
      final p = Paint()..color = col.withAlpha((q.a0 * k).round());
      if (q.add) p.blendMode = BlendMode.plus;
      c.drawCircle(Offset(q.x - cam, q.y), q.size * (.4 + .6 * k), p);
    }
    for (final m in _motes) {
      final bx = ((m[0] - cam * 1.2) % (vw + 40)) - 20 + math.sin(t / 50 + m[2]) * 6;
      final by = (m[1] - t * .12 * m[3]) % kH;
      c.drawCircle(Offset(bx, by), 1.1 * m[3], Paint()..color = Color.fromRGBO(170, 210, 255, .35 + .25 * math.sin(t / 20 + m[2]))..blendMode = BlendMode.plus);
    }
    c.restore();
    c.drawRect(
        Rect.fromLTWH(0, 0, vw, kH),
        Paint()
          ..shader = ui.Gradient.radial(Offset(vw / 2, kH / 2), math.sqrt(vw * vw + kH * kH) * .5, const [Color(0x00000000), Color(0xC0000000)], const [.45, 1]));
    if (e.flash > 0) {
      c.drawRect(Rect.fromLTWH(0, 0, vw, kH), _fill(Color.fromRGBO(255, 210, 120, e.flash * .02)));
    }
    _hud(c);
  }

  void _fog(Canvas c, ui.Image img, double y, double sp, double f) {
    final o = -((e.t * sp + e.cam * f) % kW);
    final src = Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble());
    final h = img.height / Art.ps;
    final p = Paint()..filterQuality = FilterQuality.low;
    for (double x = o; x < vw; x += kW) {
      c.drawImageRect(img, src, Rect.fromLTWH(x, y, kW + 0.5, h), p);
    }
  }

  void _props(Canvas c, int layer) {
    final cam = e.cam;
    final p = Paint()..filterQuality = FilterQuality.medium;
    for (final o in a.props) {
      if (o.layer != layer) continue;
      final img = a.sp[o.dark ? '${o.k}_d' : o.k]!;
      final w = o.h * img.width / img.height;
      final px = o.x - cam;
      if (px + w < 0 || px - w > vw) continue;
      final pp = (cfg.world == 3 && (o.k == 'n_mush' || o.k == 'n_lae'))
          ? (Paint()
            ..filterQuality = FilterQuality.medium
            ..colorFilter = ColorFilter.mode(_mushTint(o.x), BlendMode.modulate))
          : p;
      if (o.glw != null) {
        glow(c, px, kFloorY - o.h * .5, o.h * 1.2, o.glw!, .30 + math.sin(e.t / 40 + o.x) * .08, add: true);
      }
      c.drawImageRect(img, Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()), Rect.fromLTWH(px - w / 2, kFloorY - o.h, w, o.h), pp);
    }
  }

  Color _mushTint(double x) {
    const tints = [Color(0xFFC890FF), Color(0xFF9CFFB0), Color(0xFFFF9CE0)];
    return tints[(x / 37).floor() % 3];
  }

  // ---------------- المنصات
  void _platforms(Canvas c) {
    final cam = e.cam;
    for (final s in cfg.solids) {
      final px = (s.x - cam).roundToDouble();
      if (px > vw || px + s.w < 0 || (s.h > 100 && s.y < 10)) continue;
      final thin = s.h < 30;
      c.save();
      c.translate(px, s.y);
      c.drawRect(Rect.fromLTWH(0, 0, s.w, s.h), (thin && th.wood) ? a.woodPaint : a.gtPaint);
      if (thin) c.drawRect(Rect.fromLTWH(0, s.h - 3, s.w, 3), _fill(const Color(0x59000000)));
      c.restore();
      _topDecor(c, px, s.x, s.y, s.w, thin ? 14.0 : s.h, thin);
    }
  }

  void _topDecor(Canvas c, double px, double wx, double y, double w, double h, bool thin) {
    final t = e.t;
    c.drawRect(Rect.fromLTWH(px, y, w, 2), _fill(th.edge));
    c.drawRect(Rect.fromLTWH(px, y + 2, w, 1), _fill(th.edgeGlow));
    final lo = math.max(0.0, -px), hi = math.min(w, vw - px);
    final g1 = Path(), g2 = Path(), g3 = Path();
    for (double i = lo - (lo % 2); i < hi; i += 2) {
      final hv = hh(wx + i), bh = hv * 4 + 1, sw = math.sin(t / 35 + i * .3) * .7;
      (hv > .55 ? g1 : g2).addRect(Rect.fromLTWH(px + i + sw, y - bh, 1.2, bh + 1));
      if (hv > .93) g3.addRect(Rect.fromLTWH(px + i + sw, y - bh - 1.5, 1.4, 1.4));
    }
    c.drawPath(g1, _fill(th.grass1));
    c.drawPath(g2, _fill(th.grass2));
    c.drawPath(g3, Paint()..color = th.grassTip..blendMode = BlendMode.plus);
    if (thin) {
      final sp = Path();
      for (double i = lo + 4 - (lo % 10); i < hi; i += 10) {
        final d = hh(wx * 3 + i) * 7 + 2;
        sp.moveTo(px + i - 2, y + h);
        sp.lineTo(px + i, y + h + d);
        sp.lineTo(px + i + 2, y + h);
        sp.close();
      }
      c.drawPath(sp, _fill(th.spikes[0]));
    }
  }

  /// نقاط الحفظ: فانوس على عمود، يضيء عند التفعيل
  void _checkpoints(Canvas c) {
    final cs = cfg.checks;
    if (cs.isEmpty) return;
    final t = e.t;
    for (int i = 0; i < cs.length; i++) {
      final k = cs[i];
      final px = k.x - e.cam;
      if (px < -40 || px > vw + 40) continue;
      final lit = e.cpIdx >= i;
      final gy = k.gy;
      c.drawRect(Rect.fromLTWH(px - 2, gy - 46, 4, 46), _fill(const Color(0xFF3A3F4A)));
      c.drawRect(Rect.fromLTWH(px - 8, gy - 4, 16, 4), _fill(const Color(0xFF2A2E38)));
      c.drawLine(Offset(px, gy - 46), Offset(px + 9, gy - 46), Paint()..color = const Color(0xFF555A66)..strokeWidth = 2);
      final ly = gy - 40;
      final lx = px + 9;
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(lx - 5, ly, 10, 14), const Radius.circular(3)), _fill(lit ? const Color(0xFFFFD27A) : const Color(0xFF4A505E)));
      if (lit) {
        glow(c, lx, ly + 7, 34 + math.sin(t / 8.0) * 4, const C3(255, 190, 90), .6, add: true);
      } else {
        glow(c, lx, ly + 7, 14, const C3(140, 180, 255), .25 + math.sin(t / 20.0) * .08, add: true);
      }
    }
  }

  void _movers(Canvas c) {
    final cam = e.cam;
    for (final m in e.movs) {
      final px = m.x - cam;
      if (px > vw + 20 || px + m.w < -20) continue;
      if (cfg.world == 3) {
        _mushPlat(c, px, m.y, m.w, hue: (m.ox ~/ 50) % 3);
        continue;
      }
      final rope = Paint()..color = const Color(0xAA3A2A1A)..strokeWidth = 1.2;
      c.drawLine(Offset(px + 6, m.y), Offset(px + 6, m.y - 70), rope);
      c.drawLine(Offset(px + m.w - 6, m.y), Offset(px + m.w - 6, m.y - 70), rope);
      c.save();
      c.translate(px, m.y);
      c.drawRect(Rect.fromLTWH(0, 0, m.w, 14), th.wood ? a.woodPaint : a.gtPaint);
      c.restore();
      _topDecor(c, px, m.ox, m.y, m.w, 14, true);
      glow(c, px + m.w / 2, m.y + 16, 22, th.orb, .25, add: true);
    }
  }

  void _crumbles(Canvas c) {
    final cam = e.cam;
    for (final m in e.crums) {
      if (!m.active) continue;
      final px = m.x - cam;
      if (px > vw + 20 || px + m.w < -20) continue;
      final shk = m.timer >= 0 ? math.sin(e.t * 2.2) * 1.4 : 0.0;
      if (cfg.world == 3) {
        // فطر ينكمش ويختفي عند الوقوف عليه
        final sc = m.timer >= 0 ? (0.45 + 0.55 * m.timer / 28) : 1.0;
        _mushPlat(c, px + shk, m.y + (m.timer >= 0 ? (28 - m.timer) * .06 : 0), m.w, sc: sc, hue: (m.x ~/ 70) % 3);
        continue;
      }
      final rail = Paint()..color = const Color(0xCC5A4026)..strokeWidth = 1.3;
      c.drawLine(Offset(px, m.y - 20), Offset(px + 70, m.y - 20), rail);
      c.drawLine(Offset(px, m.y - 20), Offset(px, m.y), rail);
      c.save();
      c.translate(px + shk, m.y + (m.timer >= 0 ? (28 - m.timer) * .06 : 0));
      c.drawRect(Rect.fromLTWH(0, 0, m.w, 14), th.wood ? a.woodPaint : a.gtPaint);
      c.drawRect(Rect.fromLTWH(0, 0, m.w, 2), _fill(const Color(0x55FFD7A0)));
      if (m.timer >= 0) c.drawRect(Rect.fromLTWH(0, 0, m.w, 14), _fill(Color.fromRGBO(255, 120, 60, (28 - m.timer) / 28 * .35)));
      c.restore();
    }
  }

  /// منصة على شكل قبعة فطر مضيئة (العالم الثالث)
  void _mushPlat(Canvas c, double px, double y, double w, {double sc = 1.0, double a = 1.0, int hue = 0}) {
    const caps = [Color(0xFF8A3CC8), Color(0xFF2FA86A), Color(0xFFC2459A)];
    const lights = [Color(0xFFD9A8FF), Color(0xFF9CFFB8), Color(0xFFFFB0E0)];
    final cap = caps[hue % 3], lt = lights[hue % 3];
    final cw = w * sc;
    final cx = px + w / 2;
    final x0 = cx - cw / 2;
    c.drawRect(Rect.fromLTWH(cx - 3, y + 10, 6, 20 * sc + 4), Paint()..color = Color.fromRGBO(220, 210, 190, .5 * a));
    glow(c, cx, y + 4, w * .8 + 10, C3(lt.red, lt.green, lt.blue), .22 * a * sc, add: true);
    final path = Path()
      ..moveTo(x0 - 2, y + 10)
      ..quadraticBezierTo(x0 + cw * .25, y - 5, cx, y - 3)
      ..quadraticBezierTo(x0 + cw * .75, y - 5, x0 + cw + 2, y + 10)
      ..quadraticBezierTo(cx, y + 18, x0 - 2, y + 10)
      ..close();
    c.drawPath(path, Paint()..shader = ui.Gradient.linear(Offset(cx, y - 3), Offset(cx, y + 16), [lt.withOpacity(a), cap.withOpacity(a)]));
    c.drawPath(path, Paint()..color = const Color(0x55000000)..style = PaintingStyle.stroke..strokeWidth = 1);
    final n = math.max(2, (w / 26).floor());
    for (int i = 0; i < n; i++) {
      c.drawCircle(Offset(x0 + cw * (i + .5) / n, y + 3 + (i % 2) * 3), 2.0 * sc, Paint()..color = const Color(0xFFFFFFFF).withOpacity(.75 * a));
    }
    c.drawLine(Offset(x0 + 3, y + 1), Offset(x0 + cw - 3, y + 1), Paint()..color = lt.withOpacity(.55 * a)..strokeWidth = 1.2);
  }

  /// ضباب سام: جزيئات متحركة داخل المناطق + تعتيم أخضر يضيّق رؤية اللاعب
  void _fogZones(Canvas c) {
    if (cfg.fogs.isEmpty) return;
    final cam = e.cam, t = e.t;
    for (final f in cfg.fogs) {
      final x0 = f.x0 - cam, x1 = f.x1 - cam;
      if (x1 < -60 || x0 > vw + 60) continue;
      final lo = math.max(x0, -60.0), hi = math.min(x1, vw + 60.0);
      for (double xx = lo; xx < hi; xx += 54) {
        final wx = xx + cam;
        for (int j = 0; j < 4; j++) {
          final by = 130 + j * 85 + math.sin(t / 60 + wx * .02 + j) * 16;
          final bx = xx + math.sin(t / 90 + j * 1.7 + wx * .013) * 24;
          glow(c, bx, by, 74, const C3(120, 220, 90), .11 * f.density, add: true);
        }
      }
    }
    if (e.fogA > .01) {
      final dx = e.p.x - cam + 7, dy = e.p.y + 11;
      c.drawRect(
          Rect.fromLTWH(-12, -12, vw + 24, kH + 24),
          Paint()
            ..shader = ui.Gradient.radial(Offset(dx, dy), 240 - 110 * e.fogA, [Color.fromRGBO(30, 70, 26, 0), Color.fromRGBO(12, 30, 10, .94 * e.fogA)], const [0.25, 1.0]));
    }
  }

  void _hazards(Canvas c) {
    final cam = e.cam, t = e.t;
    for (final h in e.haz) {
      final px = h.x - cam;
      if (px > vw + 20 || px + h.w < -20) continue;
      if (h.kind == 2) {
        _pool(c, h, px);
        continue;
      }
      final path = Path();
      final tips = Path();
      final n = (h.w / 6).ceil();
      for (int i = 0; i < n; i++) {
        final bx = px + i * (h.w / n);
        final hv = hh(h.x + i * 3.1);
        final hgt = h.h * (.75 + hv * .5);
        path.moveTo(bx - 1, h.y + h.h);
        path.quadraticBezierTo(bx + (h.w / n) * .3, h.y + h.h - hgt * .6, bx + (h.w / n) * .5 + (hv - .5) * 3, h.y + h.h - hgt);
        path.quadraticBezierTo(bx + (h.w / n) * .7, h.y + h.h - hgt * .5, bx + h.w / n + 1, h.y + h.h);
        path.close();
        tips.addOval(Rect.fromCenter(center: Offset(bx + (h.w / n) * .5 + (hv - .5) * 3, h.y + h.h - hgt), width: 2.6, height: 2.6));
      }
      glow(c, px + h.w / 2, h.y + 6, h.w * .9, cfg.world == 3 ? const C3(170, 255, 80) : (th.wall == WallStyle.trunks ? const C3(255, 90, 74) : const C3(140, 200, 255)), .18 + math.sin(t / 14 + h.x) * .06, add: true);
      c.drawPath(path, _fill(th.hazA));
      c.drawPath(path, Paint()..color = const Color(0x55000000)..style = PaintingStyle.stroke..strokeWidth = .8);
      c.drawPath(tips, Paint()..color = th.hazB..blendMode = BlendMode.plus);
    }
  }

  void _chests(Canvas c) {
    final cam = e.cam;
    for (final ch in e.chests) {
      final px = ch.x - cam;
      if (px < -30 || px > vw + 30) continue;
      final img = a.sp[ch.open ? 'chest_d' : 'chest']!;
      if (!ch.open) glow(c, px + 9, ch.y + 6, 24, const C3(255, 200, 90), .35 + math.sin(e.t / 14) * .1, add: true);
      c.drawImageRect(img, Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()), Rect.fromLTWH(px, ch.y, 20, 14),
          Paint()..filterQuality = FilterQuality.medium);
      if (ch.open && ch.anim < 30) {
        glow(c, px + 10, ch.y - ch.anim * 1.2, 20, const C3(255, 220, 120), .8 * (1 - ch.anim / 30), add: true);
      }
    }
  }

  void _embers(Canvas c) {
    final t = e.t, cam = e.cam;
    for (final m in e.embers) {
      if (m.taken) continue;
      final x = m.x - cam;
      if (x < -20 || x > vw + 20) continue;
      final y = m.y + math.sin(t / 18 + m.x) * 3;
      glow(c, x, y, 20, const C3(255, 170, 70), .55, add: true);
      c.drawCircle(Offset(x, y), 3.6, Paint()..shader = ui.Gradient.radial(Offset(x, y), 4, const [Color(0xFFFFFFFF), Color(0xFFFFC85A)]));
      final r = t / 25 + m.x;
      final sp = Paint()..color = const Color(0xCCFFE6A8)..strokeWidth = 1;
      c.drawLine(Offset(x + math.cos(r) * 7, y + math.sin(r) * 7), Offset(x - math.cos(r) * 7, y - math.sin(r) * 7), sp);
    }
  }

  void _goal(Canvas c) {
    final t = e.t;
    final gx = cfg.goalX - e.cam, gy = cfg.goalY;
    if (gx < -150 || gx > vw + 150) return;
    final open = e.goalOpen;
    final pulse = (.7 + math.sin(t / 20) * .15) * (open ? 1.0 : .25);
    glow(c, gx, gy + 20, 110, const C3(190, 120, 255), pulse, add: true);
    glow(c, gx, gy + 25, 60, const C3(230, 200, 255), open ? .6 : .12, add: true);
    final cy = gy + 25;
    c.drawOval(Rect.fromCenter(center: Offset(gx, cy), width: 30, height: 100),
        Paint()..shader = ui.Gradient.radial(Offset(gx, cy), 50, open ? const [Color(0xFFFFFFFF), Color(0xFFE6C8FF), Color(0xFF9B5CFF)] : const [Color(0xFF3A2A50), Color(0xFF241838), Color(0xFF140C22)], const [0, .5, 1]));
    if (!open) return;
    for (int i = 0; i < 3; i++) {
      final ang = t / (18.0 + i * 7) + i * 2;
      c.drawArc(Rect.fromCenter(center: Offset(gx, cy), width: 40 + i * 14, height: 108 + i * 10), ang, 1.6, false,
          Paint()..color = const Color.fromRGBO(220, 180, 255, .6)..style = PaintingStyle.stroke..strokeWidth = 1.6..blendMode = BlendMode.plus);
    }
    for (int i = 0; i < 10; i++) {
      final ph = (t / 70 + i / 10) % 1;
      final px = gx + math.sin(i * 7.3 + t / 40) * 22, py = cy + 50 - ph * 110;
      c.drawCircle(Offset(px, py), 1.8, Paint()..color = Color.fromRGBO(240, 220, 255, 1 - ph)..blendMode = BlendMode.plus);
    }
  }

  void _vines(Canvas c) {
    final t = e.t, cam = e.cam;
    for (int i = 0; i < 16; i++) {
      final bx = ((i * 131.0) - cam * 1.15) % (vw + 120) - 60;
      final len = 60 + (i * 37) % 90;
      final sw = math.sin(t / 50 + i) * 6;
      final p = Path()
        ..moveTo(bx, -4)
        ..quadraticBezierTo(bx + sw * .5, len * .5, bx + sw, len.toDouble());
      c.drawPath(p, Paint()..color = const Color(0xFF0B2412)..style = PaintingStyle.stroke..strokeWidth = 1.8);
      for (int k = 1; k < 5; k++) {
        c.drawCircle(Offset(bx + sw * k / 5 * .8, len * k / 5.0), 1.8, _fill(const Color(0xAA1E5A2A)));
      }
    }
  }

  // ---------------- الأعداء
  void _enemy(Canvas c, Enemy en) {
    final t = e.t;
    final ex = en.x - e.cam;
    if (ex < -40 || ex > vw + 40) return;
    final flashed = en.hit > 0 && en.kb > 0;
    final body = _fill(flashed ? Colors.white : const Color(0xFF2B1B2E));
    if (en.kind == 2) {
      _spiderSmall(c, en, ex, flashed);
      return;
    }
    if (en.kind == 3) {
      _shooter(c, en, ex, flashed);
      return;
    }
    if (en.kind == 4) {
      _wraith(c, en, ex, flashed);
      return;
    }
    if (en.kind == 5) {
      _sporeling(c, en, ex, flashed);
      return;
    }
    if (en.kind == 6) {
      _sporeFly(c, en, ex, flashed);
      return;
    }
    if (en.flying) {
      final cx = ex + 9, cy = en.y + 6;
      glow(c, cx, cy, 30, const C3(255, 90, 120), .35, add: true);
      final fl = math.sin(t / 3.5) * 7;
      for (final sgn in const [-1.0, 1.0]) {
        final w = Path()
          ..moveTo(cx, cy)
          ..quadraticBezierTo(cx + sgn * 12, cy - 12 - fl, cx + sgn * 24, cy - 4 - fl * .5)
          ..quadraticBezierTo(cx + sgn * 14, cy + 2, cx, cy + 4)
          ..close();
        c.drawPath(w, body);
      }
      c.drawOval(Rect.fromCenter(center: Offset(cx, cy), width: 12, height: 14), body);
      c.drawCircle(Offset(cx - 2.5, cy - 1), 1.4, _fill(const Color(0xFFFF5A7A)));
      c.drawCircle(Offset(cx + 2.5, cy - 1), 1.4, _fill(const Color(0xFFFF5A7A)));
      return;
    }
    glow(c, ex + 9, en.y + 8, 26, const C3(255, 106, 77), .22, add: true);
    final legs = Paint()..color = (flashed ? Colors.white : const Color(0xFF2B1B2E))..strokeWidth = 2..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    for (int i = 0; i < 3; i++) {
      final o = math.sin(t / 6 + i) * 2;
      c.drawLine(Offset(ex + 3 + i * 6, en.y + 11), Offset(ex + 1.5 + i * 6 + o, en.y + 15), legs);
    }
    final dome = Path()
      ..moveTo(ex - 1, en.y + 12)
      ..quadraticBezierTo(ex + 9, en.y - 8, ex + 19, en.y + 12)
      ..close();
    c.drawPath(dome, flashed ? _fill(Colors.white) : (Paint()..shader = ui.Gradient.linear(Offset(ex, en.y - 2), Offset(ex, en.y + 12), const [Color(0xFF4A2F55), Color(0xFF1C1020)])));
    for (int i = 0; i < 3; i++) {
      c.drawCircle(Offset(ex + 5 + i * 4.5, en.y + 4 + (i % 2) * 2), 1, _fill(const Color(0xAA4FE3C1)));
    }
    final ex2 = ex + (en.d > 0 ? 12.5 : 5.5);
    glow(c, ex2, en.y + 5.5, 6, const C3(255, 106, 77), .8, add: true);
    c.drawCircle(Offset(ex2, en.y + 5.5), 1.8, _fill(const Color(0xFFFF8A5D)));
  }

  void _spiderSmall(Canvas c, Enemy en, double ex, bool flashed) {
    final t = e.t;
    final cx = ex + 10, cy = en.y + 7;
    final col = flashed ? Colors.white : const Color(0xFF1A1220);
    glow(c, cx, cy, 24, const C3(120, 255, 120), .22, add: true);
    final legs = Paint()..color = col..strokeWidth = 1.3..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    for (int i = 0; i < 4; i++) {
      for (final sg in const [-1.0, 1.0]) {
        final sw = math.sin(t / 5 + i * 1.3 + (sg > 0 ? 1.5 : 0)) * 2;
        final kx = cx + sg * (6 + i * 1.6), ky = cy - 5 - (i == 0 || i == 3 ? 0 : 1) + sw * .3;
        final fx = cx + sg * (11 + i * 2.2), fy = cy + 5 + (en.jy < 0 ? -3 : 0) + sw * .4;
        c.drawPath(Path()..moveTo(cx + sg * 2, cy)..lineTo(kx, ky)..lineTo(fx, fy), legs);
      }
    }
    c.drawOval(Rect.fromCenter(center: Offset(cx - en.d * 2.5, cy + 1), width: 12, height: 9), _fill(col));
    c.drawOval(Rect.fromCenter(center: Offset(cx + en.d * 4, cy), width: 7, height: 6), _fill(col));
    c.drawCircle(Offset(cx - en.d * 2.5, cy), 1.3, _fill(const Color(0xAA79FF6A)));
    final ey = cx + en.d * 5.2;
    glow(c, ey, cy - 1, 5, const C3(120, 255, 120), .8, add: true);
    c.drawCircle(Offset(ey, cy - 1), 1.1, _fill(const Color(0xFFB6FF9A)));
    c.drawCircle(Offset(ey - en.d * 1.8, cy - 1.2), .9, _fill(const Color(0xFFB6FF9A)));
  }

  // ---------------- الزعيم: ملك العناكب
  void _boss(Canvas c) {
    if (e.boss!.kind != 0) {
      _bossGeneric(c);
      return;
    }
    final b = e.boss!;
    final cx = b.x + b.w / 2 - e.cam;
    if (cx < -120 || cx > vw + 120) return;
    if (b.st == 'dead' && b.dead > 140) return;
    final t = e.t;
    final flashed = b.hit > 0;
    final stun = b.st == 'stun';
    double shk = 0;
    if (b.st == 'charge' && b.t < 32) shk = math.sin(t * 1.8) * 2.2;
    if (b.st == 'dead') shk = math.sin(t * 2.4) * 3;
    final cy = b.y + b.h / 2;
    final face = b.dir.toDouble();
    final fade = b.st == 'dead' ? math.max(0.0, 1 - math.max(0, b.dead - 60) / 80) : 1.0;
    c.saveLayer(Rect.fromLTWH(cx - 130, cy - 120, 260, 200), Paint()..color = Color.fromRGBO(255, 255, 255, fade));
    c.translate(shk, 0);
    c.drawOval(Rect.fromCenter(center: Offset(cx, kFloorY), width: 130, height: 12), _fill(const Color(0x66000000)));
    final dark = flashed ? Colors.white : const Color(0xFF1B1226);
    final mid = flashed ? Colors.white : const Color(0xFF3A2250);
    final legP = Paint()..color = dark..strokeWidth = 5..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round;
    final moving = b.st == 'idle' || b.st == 'charge';
    for (int i = 0; i < 4; i++) {
      for (final sg in const [-1.0, 1.0]) {
        final ph = moving ? math.sin(t / (b.st == 'charge' ? 2.5 : 7) + i * 1.5 + (sg > 0 ? 1.6 : 0)) : 0.0;
        final hipX = cx + sg * (16 + i * 4), hipY = cy + 2;
        final kneeX = cx + sg * (50 + i * 9), kneeY = cy - 30 + i * 9 - (ph > 0 ? ph * 7 : 0);
        final footX = cx + sg * (66 + i * 12) + ph * 4, footY = kFloorY - (ph > 0 ? ph * 6 : 0);
        c.drawPath(Path()..moveTo(hipX, hipY)..lineTo(kneeX, kneeY)..lineTo(footX, footY), legP);
      }
    }
    final abX = cx - face * 22;
    c.drawOval(Rect.fromCenter(center: Offset(abX, cy - 4), width: 74, height: 56),
        Paint()..shader = flashed ? null : ui.Gradient.radial(Offset(abX - 8, cy - 18), 44, [mid, dark]));
    if (flashed) c.drawOval(Rect.fromCenter(center: Offset(abX, cy - 4), width: 74, height: 56), _fill(Colors.white));
    final markC = stun ? const C3(255, 226, 122) : (b.enraged ? const C3(255, 58, 42) : const C3(184, 74, 255));
    final markA = stun ? .9 + math.sin(t / 3) * .1 : .55;
    glow(c, abX, cy - 6, stun ? 34 : 20, markC, markA, add: true);
    final mark = Path()
      ..moveTo(abX - 8, cy - 18)
      ..lineTo(abX + 8, cy - 18)
      ..lineTo(abX, cy - 6)
      ..lineTo(abX + 8, cy + 6)
      ..lineTo(abX - 8, cy + 6)
      ..lineTo(abX, cy - 6)
      ..close();
    c.drawPath(mark, Paint()..color = markC.a(markA > 1 ? 1.0 : markA));
    final hx = cx + face * 26;
    c.drawOval(Rect.fromCenter(center: Offset(hx, cy + 2), width: 40, height: 34), _fill(flashed ? Colors.white : const Color(0xFF2A1A3A)));
    for (int i = 0; i < 4; i++) {
      final ex = hx + face * (6 + (i % 2) * 7), ey = cy - 3 + (i ~/ 2) * 7;
      final ec = b.enraged ? const C3(255, 60, 40) : const C3(255, 200, 60);
      glow(c, ex, ey, 7, ec, .8, add: true);
      c.drawCircle(Offset(ex, ey), 2.1, _fill(b.enraged ? const Color(0xFFFF6A50) : const Color(0xFFFFE27A)));
    }
    final fang = _fill(const Color(0xFFEDE6D0));
    for (final sg in const [-1.0, 1.0]) {
      c.drawPath(
          Path()
            ..moveTo(hx + face * 14 + sg * 3, cy + 12)
            ..lineTo(hx + face * 14 + sg * 5, cy + 22)
            ..lineTo(hx + face * 14 + sg * 1, cy + 12)
            ..close(),
          fang);
    }
    final crown = _fill(const Color(0xFFE8B83A));
    final crX = hx - face * 2, crY = cy - 16;
    c.drawPath(
        Path()
          ..moveTo(crX - 12, crY + 4)
          ..lineTo(crX - 10, crY - 6)
          ..lineTo(crX - 5, crY)
          ..lineTo(crX, crY - 9)
          ..lineTo(crX + 5, crY)
          ..lineTo(crX + 10, crY - 6)
          ..lineTo(crX + 12, crY + 4)
          ..close(),
        crown);
    if (b.st == 'web' && b.t < 28) {
      glow(c, hx + face * 18, cy + 8, 20 + b.t * .5, const C3(210, 255, 200), .5, add: true);
    }
    if (b.st == 'charge' && b.t < 32) {
      glow(c, cx, cy, 70, const C3(255, 60, 40), .15 + (b.t % 8) * .03, add: true);
    }
    if (b.enraged && b.st != 'dead') glow(c, cx, cy, 80, const C3(255, 50, 30), .18 + math.sin(t / 6) * .05, add: true);
    if (stun) {
      for (int i = 0; i < 4; i++) {
        final ang = t / 8 + i * math.pi / 2;
        c.drawCircle(Offset(hx + math.cos(ang) * 16, cy - 26 + math.sin(ang) * 5), 2.2, Paint()..color = const Color(0xFFFFE27A)..blendMode = BlendMode.plus);
      }
    }
    c.restore();
  }


  // ================= العناصر التفاعلية الجديدة =================
  static const Map<int, C3> _poolC3 = {
    2: C3(79, 176, 90),
    3: C3(176, 255, 58),
    5: C3(255, 106, 26),
    11: C3(255, 58, 160),
  };

  void _pool(Canvas c, Haz h, double px) {
    final t = e.t;
    final k = _poolC3[cfg.world] ?? const C3(110, 190, 255);
    final col = k.a(1.0);
    glow(c, px + h.w / 2, h.y + 4, h.w * .8, k, .32 + math.sin(t / 15 + h.x) * .06, add: true);
    final path = Path()..moveTo(px, h.y + h.h + 1);
    for (double xx = 0; xx <= h.w; xx += 6) {
      path.lineTo(px + xx, h.y + 2 + math.sin((xx + t * 2.0) / 9) * 1.8);
    }
    path
      ..lineTo(px + h.w, h.y + h.h + 1)
      ..close();
    c.drawPath(path, Paint()..shader = ui.Gradient.linear(Offset(px, h.y), Offset(px, h.y + h.h), [col, Color.lerp(col, Colors.black, .55)!]));
    c.drawPath(path, Paint()..color = const Color(0x55FFFFFF)..style = PaintingStyle.stroke..strokeWidth = .8);
    for (int i = 0; i < (h.w / 40).floor(); i++) {
      final ph = (t / 50 + i * .37 + h.x * .01) % 1;
      c.drawCircle(Offset(px + 14 + i * 40 + math.sin(i * 3.1) * 6, h.y + h.h - ph * (h.h + 10)), 1.6, Paint()..color = Color.fromRGBO(255, 255, 255, .6 * (1 - ph))..blendMode = BlendMode.plus);
    }
  }

  void _gadgets(Canvas c) {
    final cam = e.cam, t = e.t;
    for (final z in cfg.slips) {
      final x0 = z.x - cam;
      if (x0 > vw || x0 + z.w < 0) continue;
      c.drawRect(Rect.fromLTWH(x0, kFloorY - 2, z.w, 6), _fill(const Color(0xAA9FDFFF)));
      for (int i = 0; i < (z.w / 40).floor(); i++) {
        final sx = x0 + 10 + i * 40 + ((t * .6 + i * 17) % 30);
        c.drawLine(Offset(sx, kFloorY - 1), Offset(sx + 10, kFloorY - 1), Paint()..color = const Color(0xCCFFFFFF)..strokeWidth = 1);
      }
    }
    for (final v in e.vplats) {
      _vanish(c, v, v.x - cam);
    }
    for (final s in e.springsL) {
      _spring(c, s, s.x - cam);
    }
    for (final k in e.kdoors) {
      _keyDoor(c, k, cam);
    }
    for (final b in e.brks) {
      if (!b.alive) continue;
      final px = b.x - cam;
      if (px > vw + 20 || px + b.w < -20) continue;
      _brk(c, b, px);
    }
    for (final a in e.ambushes) {
      _ambushMark(c, a, a.s.x - cam);
    }
    for (final h in e.timedH) {
      final px = h.x - cam;
      if (px > vw + 60 || px + h.w < -60) continue;
      _timed(c, h, px);
    }
    for (final f in e.fallers) {
      _faller(c, f, cam);
    }
    for (final r in e.rollers) {
      if (r.active) _roller(c, r, r.x - cam);
    }
  }

  void _brk(Canvas c, Brk b, double px) {
    final fl = b.hit > 0;
    final x = px + (fl ? (e.t % 2 == 0 ? 1.0 : -1.0) : 0.0);
    final white = _fill(Colors.white);
    switch (b.kind) {
      case 1:
        final r = RRect.fromRectAndRadius(Rect.fromLTWH(x, b.y, b.w, b.h), const Radius.circular(6));
        c.drawRRect(r, fl ? white : _fill(const Color(0xFF7A4E2A)));
        c.drawRect(Rect.fromLTWH(x, b.y + 6, b.w, 3), _fill(const Color(0xFF3A3F4A)));
        c.drawRect(Rect.fromLTWH(x, b.y + b.h - 9, b.w, 3), _fill(const Color(0xFF3A3F4A)));
        break;
      case 2:
        final path = Path()
          ..moveTo(x, b.y + b.h)
          ..lineTo(x + 3, b.y + 9)
          ..lineTo(x + 11, b.y)
          ..lineTo(x + b.w - 8, b.y + 3)
          ..lineTo(x + b.w, b.y + 13)
          ..lineTo(x + b.w - 2, b.y + b.h)
          ..close();
        c.drawPath(path, fl ? white : _fill(const Color(0xFF858A98)));
        c.drawPath(path, Paint()..color = const Color(0x66000000)..style = PaintingStyle.stroke..strokeWidth = 1);
        if (b.hp < 3) c.drawLine(Offset(x + 12, b.y + 4), Offset(x + 18, b.y + 18), Paint()..color = const Color(0xAA000000)..strokeWidth = 1);
        break;
      case 5: // جذع فطر عملاق يخفي ممراً (العالم الثالث)
        final mc = fl ? Colors.white : const Color(0xFFD8CCB4);
        final stem = RRect.fromRectAndRadius(Rect.fromLTWH(x + b.w * .12, b.y + b.h * .2, b.w * .76, b.h * .8), const Radius.circular(8));
        c.drawRRect(stem, _fill(mc));
        c.drawRRect(stem, Paint()..color = const Color(0x55000000)..style = PaintingStyle.stroke..strokeWidth = 1.2);
        for (double yy = b.y + b.h * .35; yy < b.y + b.h - 6; yy += 14) {
          c.drawLine(Offset(x + b.w * .2, yy), Offset(x + b.w * .8, yy + 3), Paint()..color = const Color(0x33000000)..strokeWidth = 1);
        }
        final capP = Path()
          ..moveTo(x - 6, b.y + b.h * .3)
          ..quadraticBezierTo(x + b.w * .1, b.y - 6, x + b.w * .5, b.y - 6)
          ..quadraticBezierTo(x + b.w * .9, b.y - 6, x + b.w + 6, b.y + b.h * .3)
          ..quadraticBezierTo(x + b.w * .5, b.y + b.h * .4, x - 6, b.y + b.h * .3)
          ..close();
        glow(c, x + b.w / 2, b.y + b.h * .15, b.w * 1.1, const C3(190, 130, 255), .3, add: true);
        c.drawPath(capP, _fill(fl ? Colors.white : const Color(0xFF7A2CB4)));
        c.drawPath(capP, Paint()..color = const Color(0x66000000)..style = PaintingStyle.stroke..strokeWidth = 1.2);
        c.drawCircle(Offset(x + b.w * .3, b.y + b.h * .08), 3.4, _fill(const Color(0xFFE8C8FF)));
        c.drawCircle(Offset(x + b.w * .62, b.y + b.h * .02), 2.6, _fill(const Color(0xFFE8C8FF)));
        c.drawCircle(Offset(x + b.w * .8, b.y + b.h * .16), 2.2, _fill(const Color(0xFFE8C8FF)));
        if (b.hp < 3) c.drawLine(Offset(x + b.w * .4, b.y + b.h * .3), Offset(x + b.w * .55, b.y + b.h * .7), Paint()..color = const Color(0xAA000000)..strokeWidth = 1.2);
        break;
      case 3:
        final crW = cfg.world == 3;
        glow(c, x + b.w / 2, b.y + b.h / 2, b.h * .9, crW ? const C3(200, 120, 255) : const C3(120, 220, 255), .4, add: true);
        final path3 = Path()
          ..moveTo(x + b.w / 2, b.y)
          ..lineTo(x + b.w, b.y + b.h * .35)
          ..lineTo(x + b.w * .8, b.y + b.h)
          ..lineTo(x + b.w * .2, b.y + b.h)
          ..lineTo(x, b.y + b.h * .35)
          ..close();
        c.drawPath(path3, fl ? white : _fill(crW ? const Color(0xFFB070F0) : const Color(0xFF6FD8F0)));
        c.drawPath(path3, Paint()..color = const Color(0xAAFFFFFF)..style = PaintingStyle.stroke..strokeWidth = 1);
        break;
      case 4:
        c.drawRect(Rect.fromLTWH(x, b.y, b.w, b.h), fl ? white : _fill(const Color(0xFF2E3442)));
        for (double yy = b.y + 10; yy < b.y + b.h; yy += 10) {
          c.drawLine(Offset(x, yy), Offset(x + b.w, yy), Paint()..color = const Color(0x66000000)..strokeWidth = 1);
        }
        c.drawLine(Offset(x + b.w * .3, b.y + 4), Offset(x + b.w * .7, b.y + b.h - 6), Paint()..color = Color.fromRGBO(255, 220, 140, .35 + .2 * math.sin(e.t / 12))..strokeWidth = 1.2);
        break;
      default:
        c.drawRect(Rect.fromLTWH(x, b.y, b.w, b.h), fl ? white : _fill(const Color(0xFFA06A34)));
        final bp = Paint()..color = const Color(0xFF5A3A18)..style = PaintingStyle.stroke..strokeWidth = 1.6;
        c.drawRect(Rect.fromLTWH(x + .8, b.y + .8, b.w - 1.6, b.h - 1.6), bp);
        c.drawLine(Offset(x, b.y), Offset(x + b.w, b.y + b.h), bp);
        c.drawLine(Offset(x + b.w, b.y), Offset(x, b.y + b.h), bp);
    }
  }

  void _timed(Canvas c, TimedHaz h, double px) {
    final t = e.t;
    final s = h.s;
    final on = h.on, warn = h.warn;
    final fl = warn && (t ~/ 3) % 2 == 0;
    final cx = px + h.w / 2;
    final base = h.y + h.h;
    switch (s.kind) {
      case 0: // سلك كهربائي
        final post = _fill(const Color(0xFF3A3F4A));
        c.drawRect(Rect.fromLTWH(px - 3, h.y, 5, h.h), post);
        c.drawRect(Rect.fromLTWH(px + h.w - 2, h.y, 5, h.h), post);
        c.drawLine(Offset(px, h.y + 3), Offset(px + h.w, h.y + 3), Paint()..color = const Color(0xFF777C88)..strokeWidth = 1.2);
        if (on || fl) {
          final path = Path()..moveTo(px, h.y + 3);
          for (int i = 1; i <= 6; i++) {
            path.lineTo(px + h.w * i / 6, h.y + 3 + ((t + i * 5) % 3 - 1) * 9.0 + (i.isEven ? h.h * .5 : h.h * .15));
          }
          glow(c, cx, h.y + h.h / 2, h.w * .9, const C3(140, 210, 255), on ? .7 : .3, add: true);
          c.drawPath(path, Paint()..color = on ? const Color(0xFFE6F6FF) : const Color(0x88BEE6FF)..style = PaintingStyle.stroke..strokeWidth = on ? 1.8 : 1..blendMode = BlendMode.plus);
        }
        break;
      case 1: // أشواك تظهر
        final hh2 = on ? h.h : (warn ? 5.0 : 2.0);
        c.drawRect(Rect.fromLTWH(px, kFloorY - 2, h.w, 2), _fill(const Color(0xFF30343E)));
        final n = (h.w / 8).floor();
        for (int i = 0; i < n; i++) {
          final bx = px + i * (h.w / n);
          c.drawPath(
              Path()
                ..moveTo(bx, kFloorY - 2)
                ..lineTo(bx + h.w / n / 2, kFloorY - 2 - hh2)
                ..lineTo(bx + h.w / n, kFloorY - 2)
                ..close(),
              _fill(on ? const Color(0xFFD8DCE8) : const Color(0xFF6A6F7C)));
        }
        if (on) glow(c, cx, kFloorY - 10, h.w, const C3(255, 120, 100), .25, add: true);
        break;
      case 2: // نافورة نار
        c.drawRect(Rect.fromLTWH(px, kFloorY - 4, h.w, 4), _fill(const Color(0xFF2A1410)));
        if (on) {
          final hgt = h.h * (.92 + math.sin(t / 2.0) * .08);
          final path = Path()
            ..moveTo(px + 2, kFloorY - 4)
            ..quadraticBezierTo(px - 4, kFloorY - hgt * .5, cx, kFloorY - hgt)
            ..quadraticBezierTo(px + h.w + 4, kFloorY - hgt * .5, px + h.w - 2, kFloorY - 4)
            ..close();
          glow(c, cx, kFloorY - hgt * .5, hgt * .8, const C3(255, 120, 40), .6, add: true);
          c.drawPath(path, Paint()..color = const Color(0xCCFF7A1A)..blendMode = BlendMode.plus);
          c.drawPath(
              Path()
                ..moveTo(px + 8, kFloorY - 4)
                ..quadraticBezierTo(cx, kFloorY - hgt * .5, cx, kFloorY - hgt * .7)
                ..quadraticBezierTo(cx, kFloorY - hgt * .5, px + h.w - 8, kFloorY - 4)
                ..close(),
              Paint()..color = const Color(0xCCFFE8A0)..blendMode = BlendMode.plus);
        } else if (warn) {
          glow(c, cx, kFloorY - 8, 22, const C3(255, 120, 40), fl ? .6 : .25, add: true);
        }
        break;
      case 3: // سحابة سامة (في العالم الثالث: فطر سام ينفث السحب)
        if (cfg.world == 3) {
          final mx = cx + (warn ? math.sin(t * 2.4) * 1.2 : 0.0);
          c.drawRect(Rect.fromLTWH(mx - 3, base - 16, 6, 16), _fill(const Color(0xFFD8D0B8)));
          final cp3 = Path()
            ..moveTo(mx - 17, base - 14)
            ..quadraticBezierTo(mx - 15, base - 36 - (on ? 4 : 0), mx, base - 36)
            ..quadraticBezierTo(mx + 15, base - 36 - (on ? 4 : 0), mx + 17, base - 14)
            ..quadraticBezierTo(mx, base - 8, mx - 17, base - 14)
            ..close();
          c.drawPath(cp3, _fill(on ? const Color(0xFF9CE03A) : const Color(0xFF6A2AA8)));
          c.drawCircle(Offset(mx - 6, base - 25), 2.4, _fill(const Color(0xFFE8FFB0)));
          c.drawCircle(Offset(mx + 5, base - 27), 1.8, _fill(const Color(0xFFE8FFB0)));
          if (on || warn) {
            final al3 = on ? .55 : (fl ? .4 : .18);
            final top3 = h.y;
            for (int i = 0; i < 7; i++) {
              final ph3 = (t * .04 + i * .37) % 1.0;
              final by3 = base - 36 - ph3 * math.max(10.0, base - 36 - top3);
              final bx3 = mx + math.sin(t / 9 + i * 2) * (h.w * .35) * (on ? 1.0 : .4);
              c.drawCircle(Offset(bx3, by3), (on ? 11 : 5) * (.6 + ph3 * .6), Paint()..color = Color.fromRGBO(150, 255, 90, al3 * (1 - ph3 * .5)));
            }
            if (on) glow(c, mx, (base - 36 + top3) / 2, h.w, const C3(160, 255, 90), .35, add: true);
          }
          break;
        }
        c.drawOval(Rect.fromLTWH(px + 6, base - 8, h.w - 12, 8), _fill(const Color(0xFF3A5A2A)));
        if (on || warn) {
          final a = on ? .6 : (fl ? .35 : .15);
          for (int i = 0; i < 5; i++) {
            final bx = px + 8 + (h.w - 16) * (i / 4) + math.sin(t / 10 + i) * 4;
            final by = base - 12 - (on ? (i % 3) * 10 : (i % 2) * 3) - math.sin(t / 14 + i * 2) * 3;
            c.drawCircle(Offset(bx, by), on ? 12 : 6, Paint()..color = Color.fromRGBO(150, 255, 90, a));
          }
          if (on) glow(c, cx, base - 22, h.w, const C3(160, 255, 90), .35, add: true);
        }
        break;
      case 4: // شعاع ضوء
        c.drawRect(Rect.fromLTWH(cx - 7, h.y - 2, 14, 5), _fill(const Color(0xFF6A5A2A)));
        c.drawRect(Rect.fromLTWH(cx - 7, kFloorY - 3, 14, 3), _fill(const Color(0xFF6A5A2A)));
        if (on) {
          glow(c, cx, h.y + h.h / 2, h.h * .7, const C3(255, 240, 160), .55, add: true);
          c.drawRect(Rect.fromLTWH(cx - 5, h.y, 10, h.h), Paint()..color = const Color(0xCCFFF2B0)..blendMode = BlendMode.plus);
          c.drawRect(Rect.fromLTWH(cx - 1.5, h.y, 3, h.h), Paint()..color = const Color(0xFFFFFFFF)..blendMode = BlendMode.plus);
        } else if (warn) {
          c.drawRect(Rect.fromLTWH(cx - 1, h.y, 2, h.h), Paint()..color = Color.fromRGBO(255, 240, 160, fl ? .7 : .25)..blendMode = BlendMode.plus);
        }
        break;
      case 5: // نبات يعضّ
        final open = on;
        c.drawLine(Offset(cx, base), Offset(cx, base - 14), Paint()..color = const Color(0xFF2A6A2A)..strokeWidth = 4);
        final jaw = open ? 14.0 : (warn ? 8.0 : 3.0);
        final pc = _fill(on ? const Color(0xFFC83A5A) : const Color(0xFF3A8A3A));
        c.drawPath(
            Path()
              ..moveTo(cx - 14, base - 14)
              ..quadraticBezierTo(cx - 16, base - 14 - jaw - 8, cx, base - 14 - jaw)
              ..quadraticBezierTo(cx - 6, base - 14, cx - 14, base - 14)
              ..close(),
            pc);
        c.drawPath(
            Path()
              ..moveTo(cx + 14, base - 14)
              ..quadraticBezierTo(cx + 16, base - 14 - jaw - 8, cx, base - 14 - jaw)
              ..quadraticBezierTo(cx + 6, base - 14, cx + 14, base - 14)
              ..close(),
            pc);
        if (on) {
          for (int i = -2; i <= 2; i++) {
            c.drawLine(Offset(cx + i * 5, base - 14), Offset(cx + i * 5, base - 14 - jaw * .7), Paint()..color = const Color(0xFFFFFFFF)..strokeWidth = 1.2);
          }
        }
        break;
      case 7: // جذر حي ينفجر من الأرض أو المنصة
        {
          c.drawOval(Rect.fromLTWH(px - 2, base - 3, h.w + 4, 5), _fill(const Color(0xFF1A0E22)));
          final rh = on ? h.h * (.94 + math.sin(t / 3.0) * .06) : (warn ? 9.0 + math.sin(t * 2.6) * 3 : 3.0);
          final sw = on ? 1.0 : .55;
          final lean = math.sin(t / 9.0 + s.x) * (on ? 5.0 : 1.0);
          final root = Path()
            ..moveTo(cx - h.w * .5 * sw, base - 2)
            ..quadraticBezierTo(cx - h.w * .35 + lean, base - rh * .55, cx + lean * 1.6, base - rh)
            ..quadraticBezierTo(cx + h.w * .35 + lean, base - rh * .5, cx + h.w * .5 * sw, base - 2)
            ..close();
          c.drawPath(root, _fill(on ? const Color(0xFF5A2E6E) : const Color(0xFF3A2048)));
          c.drawPath(root, Paint()..color = const Color(0x66000000)..style = PaintingStyle.stroke..strokeWidth = 1);
          if (on) {
            for (int i = 1; i <= 3; i++) {
              final ty = base - rh * i / 4;
              final dr = i.isEven ? 1.0 : -1.0;
              c.drawLine(Offset(cx + lean * i / 3, ty), Offset(cx + dr * 11 + lean * i / 3, ty - 6), Paint()..color = const Color(0xFFB88AE0)..strokeWidth = 1.8..strokeCap = StrokeCap.round);
            }
            glow(c, cx + lean * 1.6, base - rh, 22, const C3(200, 120, 255), .55, add: true);
          } else if (warn) {
            glow(c, cx, base - 6, 20, const C3(200, 120, 255), fl ? .5 : .2, add: true);
          }
          break;
        }
      case 8: // جذر يتدلى من السقف
        {
          final top8 = h.y;
          final rl = on ? h.h * (.94 + math.sin(t / 3.0) * .06) : (warn ? 9.0 + math.sin(t * 2.6) * 3 : 3.0);
          final lean8 = math.sin(t / 9.0 + s.x) * (on ? 5.0 : 1.0);
          final sw8 = on ? 1.0 : .55;
          c.drawOval(Rect.fromLTWH(px - 3, top8 - 4, h.w + 6, 9), _fill(const Color(0xFF1A0E22)));
          final root8 = Path()
            ..moveTo(cx - h.w * .5 * sw8, top8)
            ..quadraticBezierTo(cx - h.w * .35 + lean8, top8 + rl * .55, cx + lean8 * 1.6, top8 + rl)
            ..quadraticBezierTo(cx + h.w * .35 + lean8, top8 + rl * .5, cx + h.w * .5 * sw8, top8)
            ..close();
          c.drawPath(root8, _fill(on ? const Color(0xFF5A2E6E) : const Color(0xFF3A2048)));
          c.drawPath(root8, Paint()..color = const Color(0x66000000)..style = PaintingStyle.stroke..strokeWidth = 1);
          if (on) {
            for (int i = 1; i <= 3; i++) {
              final ty = top8 + rl * i / 4;
              final dr = i.isEven ? 1.0 : -1.0;
              c.drawLine(Offset(cx + lean8 * i / 3, ty), Offset(cx + dr * 11 + lean8 * i / 3, ty + 6), Paint()..color = const Color(0xFFB88AE0)..strokeWidth = 1.8..strokeCap = StrokeCap.round);
            }
            glow(c, cx + lean8 * 1.6, top8 + rl, 22, const C3(200, 120, 255), .55, add: true);
          } else if (warn) {
            glow(c, cx, top8 + 6, 20, const C3(200, 120, 255), fl ? .5 : .2, add: true);
          }
          break;
        }
      case 9: // جذر يندفع أفقياً من الجدار (9 من اليسار، 10 من اليمين)
      case 10:
        {
          final fromLeft = s.kind == 9;
          final ax0 = fromLeft ? px : px + h.w;
          final dx9 = fromLeft ? 1.0 : -1.0;
          final cy9 = h.y + h.h / 2;
          final rl9 = on ? h.w * (.94 + math.sin(t / 3.0) * .06) : (warn ? 9.0 + math.sin(t * 2.6) * 3 : 3.0);
          final lean9 = math.sin(t / 9.0 + s.x) * (on ? 4.0 : 1.0);
          final sw9 = on ? 1.0 : .55;
          c.drawOval(Rect.fromLTWH(ax0 - 5, cy9 - h.h * .6, 10, h.h * 1.2), _fill(const Color(0xFF1A0E22)));
          final root9 = Path()
            ..moveTo(ax0, cy9 - h.h * .5 * sw9)
            ..quadraticBezierTo(ax0 + dx9 * rl9 * .55, cy9 - h.h * .35 + lean9, ax0 + dx9 * rl9, cy9 + lean9 * 1.6)
            ..quadraticBezierTo(ax0 + dx9 * rl9 * .5, cy9 + h.h * .35 + lean9, ax0, cy9 + h.h * .5 * sw9)
            ..close();
          c.drawPath(root9, _fill(on ? const Color(0xFF5A2E6E) : const Color(0xFF3A2048)));
          c.drawPath(root9, Paint()..color = const Color(0x66000000)..style = PaintingStyle.stroke..strokeWidth = 1);
          if (on) {
            for (int i = 1; i <= 3; i++) {
              final tx = ax0 + dx9 * rl9 * i / 4;
              final dr = i.isEven ? 1.0 : -1.0;
              c.drawLine(Offset(tx, cy9 + lean9 * i / 3), Offset(tx + dx9 * 6, cy9 + dr * 11 + lean9 * i / 3), Paint()..color = const Color(0xFFB88AE0)..strokeWidth = 1.8..strokeCap = StrokeCap.round);
            }
            glow(c, ax0 + dx9 * rl9, cy9 + lean9 * 1.6, 22, const C3(200, 120, 255), .55, add: true);
          } else if (warn) {
            glow(c, ax0 + dx9 * 6, cy9, 20, const C3(200, 120, 255), fl ? .5 : .2, add: true);
          }
          break;
        }
      default: // نصل متأرجح
        final bx = h.x + h.w / 2 - e.cam;
        c.drawLine(Offset(bx, h.y - 20), Offset(bx, h.y + 4), Paint()..color = const Color(0xFF555A66)..strokeWidth = 1.4);
        c.drawPath(
            Path()
              ..moveTo(bx - 7, h.y + 4)
              ..lineTo(bx + 7, h.y + 4)
              ..lineTo(bx, h.y + h.h)
              ..close(),
            _fill(const Color(0xFFD8DCE8)));
        glow(c, bx, h.y + h.h * .6, 22, const C3(200, 220, 255), .25, add: true);
        c.drawLine(Offset(px - 2, h.y - 20), Offset(px + 118, h.y - 20), Paint()..color = const Color(0x33FFFFFF)..strokeWidth = 1);
    }
  }

  void _faller(Canvas c, Faller f, double cam) {
    final x = f.s.x - cam;
    if (x < -30 || x > vw + 30) return;
    final k = f.s.kind;
    if (f.st == 1) {
      final fl = (f.tm ~/ 4) % 2 == 0;
      c.drawOval(Rect.fromCenter(center: Offset(x, kFloorY - 1), width: 26, height: 6), Paint()..color = Color.fromRGBO(255, 80, 60, fl ? .6 : .25));
      c.drawLine(Offset(x, 0), Offset(x, 14 + f.tm * .5), Paint()..color = const Color(0x55CCCCCC)..strokeWidth = 1);
      return;
    }
    if (f.st != 2) return;
    final y = f.y;
    const cols = [Color(0xFF858A98), Color(0xFFA8E4FF), Color(0xFFFF7A2A), Color(0xFF6A4A24), Color(0xFF5FE0F0), Color(0xFFB04AD8)];
    final col = cols[k.clamp(0, 5).toInt()];
    if (k == 2) glow(c, x, y, 30, const C3(255, 120, 40), .6, add: true);
    if (k == 4 || k == 1) {
      c.drawPath(
          Path()
            ..moveTo(x - 6, y - 10)
            ..lineTo(x + 6, y - 10)
            ..lineTo(x, y + 10)
            ..close(),
          _fill(col));
      c.drawPath(
          Path()
            ..moveTo(x - 6, y - 10)
            ..lineTo(x + 6, y - 10)
            ..lineTo(x, y + 10)
            ..close(),
          Paint()..color = const Color(0xAAFFFFFF)..style = PaintingStyle.stroke..strokeWidth = 1);
    } else if (k == 3) {
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(x, y), width: 26, height: 7), const Radius.circular(3)), _fill(col));
      c.drawCircle(Offset(x - 9, y + 3), 3.5, _fill(const Color(0xFF2E7A2E)));
    } else {
      c.drawCircle(Offset(x, y), 9, _fill(col));
      c.drawCircle(Offset(x - 3, y - 3), 3, Paint()..color = const Color(0x55FFFFFF));
    }
  }

  void _roller(Canvas c, Roller r, double x) {
    if (x < -30 || x > vw + 30) return;
    final rot = e.t * .25;
    final cy = kFloorY - 12;
    switch (r.s.kind) {
      case 1:
        glow(c, x, cy, 34, const C3(255, 120, 40), .7, add: true);
        c.drawCircle(Offset(x, cy), 11, _fill(const Color(0xFFFF8A2A)));
        c.drawCircle(Offset(x, cy), 6, _fill(const Color(0xFFFFE08A)));
        break;
      case 2:
        c.drawRect(Rect.fromLTWH(x - 14, cy - 8, 28, 14), _fill(const Color(0xFF5A4A3A)));
        c.drawRect(Rect.fromLTWH(x - 16, cy - 10, 32, 4), _fill(const Color(0xFF7A7F8C)));
        c.drawCircle(Offset(x - 8, cy + 7), 4, _fill(const Color(0xFF222222)));
        c.drawCircle(Offset(x + 8, cy + 7), 4, _fill(const Color(0xFF222222)));
        break;
      case 3:
        c.drawCircle(Offset(x, cy), 12, _fill(const Color(0xFFEAF6FF)));
        c.drawArc(Rect.fromCircle(center: Offset(x, cy), radius: 8), rot, 2, false, Paint()..color = const Color(0xFFA8CCE8)..style = PaintingStyle.stroke..strokeWidth = 1.5);
        break;
      case 4:
        c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(x, cy), width: 24, height: 24), const Radius.circular(10)), _fill(const Color(0xFF6A4A24)));
        c.drawArc(Rect.fromCircle(center: Offset(x, cy), radius: 7), rot, 3, false, Paint()..color = const Color(0xFF3A2410)..style = PaintingStyle.stroke..strokeWidth = 1.5);
        break;
      default:
        c.drawCircle(Offset(x, cy), 12, _fill(const Color(0xFF7E8390)));
        c.drawCircle(Offset(x, cy), 12, Paint()..color = const Color(0x66000000)..style = PaintingStyle.stroke..strokeWidth = 1.2);
        c.drawLine(Offset(x, cy), Offset(x + math.cos(rot) * 10, cy + math.sin(rot) * 10), Paint()..color = const Color(0xFF454A56)..strokeWidth = 1.6);
    }
  }

  void _spring(Canvas c, SpringPad s, double px) {
    if (px < -40 || px > vw + 40) return;
    final by = s.y + 12;
    final sq = s.anim > 0 ? 1 - s.anim / 14 : 0.0;
    final capH = (12 - (s.anim > 7 ? 5 : 0) + sq * 0) * (s.power > 1.1 ? 1.25 : (s.power < .9 ? .8 : 1.0));
    final hot = s.power > 1.1;
    final w3 = cfg.world == 3;
    final capC = w3 ? (hot ? const Color(0xFFE0409A) : (s.power < .9 ? const Color(0xFF3AC8A0) : const Color(0xFFB04AD8))) : const Color(0xFFB04AD8);
    c.drawRect(Rect.fromLTWH(px + 8, by - 5, 10, 5), _fill(const Color(0xFFE8D8B8)));
    final cap = Path()
      ..moveTo(px - 2, by - 5)
      ..quadraticBezierTo(px + 13, by - 5 - capH * 2.2, px + 28, by - 5)
      ..close();
    glow(c, px + 13, by - 8, 26, hot ? const C3(255, 120, 200) : const C3(230, 150, 255), .35 + (s.anim > 0 ? .4 : 0), add: true);
    c.drawPath(cap, _fill(capC));
    c.drawCircle(Offset(px + 8, by - 10), 1.8, _fill(const Color(0xFFF0D0FF)));
    c.drawCircle(Offset(px + 17, by - 12), 1.4, _fill(const Color(0xFFF0D0FF)));
  }

  void _keyDoor(Canvas c, KeyDoorO k, double cam) {
    final dx = k.door.x - cam;
    if (dx > -40 && dx < vw + 40) {
      final off = k.open ? math.min(1.0, k.anim / 40) * 110 : 0.0;
      if (cfg.world == 3 && !(k.open && k.anim >= 40)) {
        // باب نباتي: كروم متشابكة تتراجع عند فتحه
        c.save();
        c.clipRect(Rect.fromLTWH(dx - 3, k.door.y - 4, 30, 114));
        final y0 = k.door.y - off;
        c.drawRect(Rect.fromLTWH(dx, y0, 22, 110), _fill(const Color(0xFF1C2A18)));
        for (int i = 0; i < 4; i++) {
          final vx = dx + 3 + i * 5.0;
          final vp = Path()..moveTo(vx, y0);
          for (int j = 1; j <= 10; j++) {
            vp.lineTo(vx + math.sin(j * 1.3 + i * 1.7) * 3.2, y0 + j * 11.0);
          }
          c.drawPath(vp, Paint()..color = (i.isEven ? const Color(0xFF3E9A46) : const Color(0xFF2A7A60))..style = PaintingStyle.stroke..strokeWidth = 3);
        }
        for (int i = 0; i < 5; i++) {
          c.drawLine(Offset(dx + 1, y0 + 12 + i * 20.0), Offset(dx + 21, y0 + 6 + i * 20.0), Paint()..color = const Color(0xFFB4FF50)..strokeWidth = 1.2);
        }
        if (!k.open) {
          glow(c, dx + 11, y0 + 56, 18, const C3(180, 255, 100), .5, add: true);
          c.drawCircle(Offset(dx + 11, y0 + 56), 5, _fill(const Color(0xFFE860B0)));
          c.drawCircle(Offset(dx + 11, y0 + 56), 2.2, _fill(const Color(0xFFFFF0A0)));
        }
        c.restore();
      } else if (!(k.open && k.anim >= 40)) {
        c.save();
        c.clipRect(Rect.fromLTWH(dx - 3, k.door.y - 4, 30, 114));
        final y0 = k.door.y - off;
        c.drawRect(Rect.fromLTWH(dx, y0, 22, 110), _fill(const Color(0xFF3A3F4A)));
        for (int i = 0; i < 5; i++) {
          c.drawRect(Rect.fromLTWH(dx + 2 + i * 4, y0, 2, 110), _fill(const Color(0xFF6A707E)));
        }
        c.drawRect(Rect.fromLTWH(dx, y0 + 50, 22, 4), _fill(const Color(0xFF555A66)));
        if (!k.open) {
          glow(c, dx + 11, y0 + 56, 18, const C3(255, 210, 90), .45, add: true);
          c.drawCircle(Offset(dx + 11, y0 + 56), 4, _fill(const Color(0xFFFFC94A)));
        }
        c.restore();
      }
    }
    if (!k.taken) {
      final kx = k.s.kx - cam;
      if (kx > -20 && kx < vw + 20) {
        final ky = k.s.ky + math.sin(e.t / 14) * 2.5;
        glow(c, kx, ky, 26, const C3(255, 220, 100), .8, add: true);
        final kp = Paint()..color = const Color(0xFFFFD36A)..strokeWidth = 2.2..style = PaintingStyle.stroke;
        c.drawCircle(Offset(kx - 4, ky), 4, kp);
        c.drawLine(Offset(kx, ky), Offset(kx + 9, ky), kp);
        c.drawLine(Offset(kx + 6, ky), Offset(kx + 6, ky + 4), kp);
        c.drawLine(Offset(kx + 9, ky), Offset(kx + 9, ky + 4), kp);
      }
    }
  }

  void _vanish(Canvas c, VanishP v, double px) {
    if (px > vw + 30 || px + v.w < -30) return;
    final edge = th.edge;
    final fill = Color.lerp(th.edge, Colors.black, .6)!;
    double a = 1;
    if (v.s.hidden) {
      final d = ((e.p.x + 7) - (v.x + v.w / 2)).abs();
      a = (1 - d / 150).clamp(0.0, 1.0).toDouble() * .9;
      if (a < .08) return;
    } else if (!v.solid) {
      a = .12;
    } else if (v.warn) {
      a = (e.t ~/ 3) % 2 == 0 ? .35 : 1.0;
    }
    if (cfg.world == 3) {
      _mushPlat(c, px, v.y, v.w, a: a, hue: (v.x ~/ 60) % 3);
      return;
    }
    final r = RRect.fromRectAndRadius(Rect.fromLTWH(px, v.y, v.w, v.h), const Radius.circular(3));
    c.drawRRect(r, _fill(fill.withOpacity(a)));
    c.drawRRect(r, Paint()..color = edge.withOpacity(a)..style = PaintingStyle.stroke..strokeWidth = 1.4);
    if (v.solid) glow(c, px + v.w / 2, v.y, v.w * .8, const C3(150, 200, 255), .2 * a, add: true);
  }

  void _ambushMark(Canvas c, Ambush a, double px) {
    if (!a.s.marker || px < -30 || px > vw + 30) return;
    final y = kFloorY;
    if (!a.fired) {
      c.drawRRect(RRect.fromRectAndCorners(Rect.fromLTWH(px - 8, y - 22, 16, 22), topLeft: const Radius.circular(8), topRight: const Radius.circular(8)), _fill(const Color(0xFF5A5F6C)));
      c.drawLine(Offset(px, y - 17), Offset(px, y - 8), Paint()..color = const Color(0xFF2A2E38)..strokeWidth = 1.6);
      c.drawLine(Offset(px - 4, y - 14), Offset(px + 4, y - 14), Paint()..color = const Color(0xFF2A2E38)..strokeWidth = 1.6);
    } else if (a.anim < 50) {
      final k = a.anim / 50;
      glow(c, px, y - 10, 30 * (1 - k * .5), const C3(180, 160, 255), .6 * (1 - k), add: true);
      c.drawOval(Rect.fromCenter(center: Offset(px, y - 1), width: 30, height: 5), _fill(const Color(0xFF2A2018)));
    } else {
      c.drawOval(Rect.fromCenter(center: Offset(px, y - 1), width: 30, height: 5), _fill(const Color(0xFF2A2018)));
    }
  }

  void _shooter(Canvas c, Enemy en, double ex, bool flashed) {
    final t = e.t;
    final dir = en.d >= 0 ? 1.0 : -1.0;
    final base = flashed ? Colors.white : const Color(0xFF3A3F4A);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(ex, en.y, 18, 13), const Radius.circular(3)), _fill(base));
    c.drawRect(Rect.fromLTWH(dir > 0 ? ex + 12 : ex - 8, en.y + 4, 14, 4), _fill(flashed ? Colors.white : const Color(0xFF22252C)));
    final charge = en.hopT < 20;
    glow(c, ex + 9, en.y + 5, charge ? 18 : 10, const C3(255, 120, 60), charge ? .9 : .5, add: true);
    c.drawCircle(Offset(ex + 9 + dir * 2, en.y + 5), 2.2, _fill(const Color(0xFFFF8A4A)));
    c.drawCircle(Offset(ex + 4, en.y + 12 + math.sin(t / 8) * .3), 1.2, _fill(const Color(0xFF8A8F9C)));
  }

  /// جرثومة فطرية صغيرة مطاردة
  void _sporeling(Canvas c, Enemy en, double ex, bool flashed) {
    final t = e.t;
    final cx = ex + 9;
    final chase = (e.p.x - en.x).abs() < 230;
    glow(c, cx, en.y + 6, 26, chase ? const C3(255, 90, 140) : const C3(170, 255, 90), .3, add: true);
    final leg = Paint()
      ..color = (flashed ? Colors.white : const Color(0xFFD8D0B8))
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round;
    final st = math.sin(t / (chase ? 3 : 6)) * 2.2;
    c.drawLine(Offset(cx - 3, en.y + 8), Offset(cx - 4 + st, en.y + 13), leg);
    c.drawLine(Offset(cx + 3, en.y + 8), Offset(cx + 4 - st, en.y + 13), leg);
    final capP = Path()
      ..moveTo(cx - 11, en.y + 9)
      ..quadraticBezierTo(cx - 10, en.y - 9, cx, en.y - 9)
      ..quadraticBezierTo(cx + 10, en.y - 9, cx + 11, en.y + 9)
      ..close();
    c.drawPath(capP, _fill(flashed ? Colors.white : (chase ? const Color(0xFFA02A6A) : const Color(0xFF6A2AA8))));
    c.drawCircle(Offset(cx - 5, en.y - 2), 1.8, _fill(const Color(0xFFE8C8FF)));
    c.drawCircle(Offset(cx + 4, en.y - 4), 1.4, _fill(const Color(0xFFE8C8FF)));
    final fx = cx + (en.d > 0 ? 3.0 : -3.0);
    glow(c, fx, en.y + 6, 6, const C3(255, 140, 80), .8, add: true);
    c.drawCircle(Offset(fx - 2, en.y + 6), 1.3, _fill(const Color(0xFFFF8A5D)));
    c.drawCircle(Offset(fx + 2, en.y + 6), 1.3, _fill(const Color(0xFFFF8A5D)));
  }

  /// جرثومة طائرة تطلق مقذوفات
  void _sporeFly(Canvas c, Enemy en, double ex, bool flashed) {
    final t = e.t;
    final cx = ex + 9, cy = en.y + 6;
    final charge = en.hopT < 24;
    glow(c, cx, cy, charge ? 40 : 30, const C3(170, 255, 90), charge ? .6 : .35, add: true);
    final fl = math.sin(t / 3.0) * 6;
    for (final sg in const [-1.0, 1.0]) {
      final w = Path()
        ..moveTo(cx, cy)
        ..quadraticBezierTo(cx + sg * 12, cy - 10 - fl, cx + sg * 22, cy - 3 - fl * .5)
        ..quadraticBezierTo(cx + sg * 12, cy + 3, cx, cy + 3)
        ..close();
      c.drawPath(w, Paint()..color = const Color(0x88C8FF9A));
    }
    c.drawCircle(Offset(cx, cy), 8, _fill(flashed ? Colors.white : const Color(0xFF3A8A3A)));
    for (int i = 0; i < 4; i++) {
      final an = t / 18 + i * math.pi / 2;
      c.drawCircle(Offset(cx + math.cos(an) * 5, cy + math.sin(an) * 5), 1.4, _fill(const Color(0xFFE0FF9A)));
    }
    c.drawCircle(Offset(cx - 2.5, cy - 1), 1.5, _fill(const Color(0xFFFF5A7A)));
    c.drawCircle(Offset(cx + 2.5, cy - 1), 1.5, _fill(const Color(0xFFFF5A7A)));
  }

  void _wraith(Canvas c, Enemy en, double ex, bool flashed) {
    final t = e.t;
    final cx = ex + 9, cy = en.y + 6;
    glow(c, cx, cy, 34, const C3(170, 150, 255), .4, add: true);
    final body = Path()..moveTo(cx - 9, cy + 4);
    body.quadraticBezierTo(cx - 12, cy - 14, cx, cy - 14);
    body.quadraticBezierTo(cx + 12, cy - 14, cx + 9, cy + 4);
    for (int i = 0; i < 4; i++) {
      final bx = cx + 9 - i * 6.0;
      body.quadraticBezierTo(bx - 1.5, cy + 12 + math.sin(t / 5 + i) * 3, bx - 3, cy + 4);
    }
    body.close();
    c.drawPath(body, _fill(flashed ? Colors.white : const Color(0xBBB8B0F0)));
    c.drawCircle(Offset(cx - 3, cy - 5), 1.8, _fill(const Color(0xFF241A4A)));
    c.drawCircle(Offset(cx + 3, cy - 5), 1.8, _fill(const Color(0xFF241A4A)));
  }

  // ---------- الزعماء ذوو التصميم الخاص (كل زعيم بشكل وهجمات مختلفة)
  void _bossGeneric(Canvas c) {
    final b = e.boss!;
    final cx = b.x + b.w / 2 - e.cam;
    if (cx < -140 || cx > vw + 140) return;
    if (b.st == 'dead' && b.dead > 140) return;
    final t = e.t, k = b.kind;
    final flashed = b.hit > 0;
    final stun = b.st == 'stun';
    double shk = 0;
    if (b.st == 'charge' && b.t < 32) shk = math.sin(t * 1.8) * 2.2;
    if (b.st == 'roar') shk = math.sin(t * 2.2) * 3;
    if (b.st == 'quake' && b.t < 20) shk = math.sin(t * 1.8) * 2;
    if (b.st == 'dead') shk = math.sin(t * 2.4) * 3;
    final cy = b.y + b.h / 2;
    final face = b.dir.toDouble();
    final fade = b.st == 'dead' ? math.max(0.0, 1 - math.max(0, b.dead - 60) / 80) : 1.0;
    // ألوان: [أساس، لون ثانوي، توهج]
    const pal = <int, List<Color>>{
      1: [Color(0xFF5A5F6B), Color(0xFF9AA0AE), Color(0xFF6AE0FF)],
      3: [Color(0xFF5B2E6E), Color(0xFFB03AE0), Color(0xFFE0A0FF)],
      4: [Color(0xFFE8E0C8), Color(0xFFB8B09A), Color(0xFF7CFF9A)],
      5: [Color(0xFF4A1408), Color(0xFFB4400E), Color(0xFFFF6A1A)],
      6: [Color(0xFF8ACBEA), Color(0xFFE8F6FF), Color(0xFFBDEFFF)],
      7: [Color(0xFF1E2030), Color(0xFF3A3E58), Color(0xFF9ACBFF)],
      8: [Color(0xFFB88A3A), Color(0xFF7A5A1E), Color(0xFFFFE27A)],
      9: [Color(0xFF2AA0C0), Color(0xFF7FE6FF), Color(0xFFB0F4FF)],
      10: [Color(0xFF120C1C), Color(0xFF2A1A3A), Color(0xFFB84AFF)],
      11: [Color(0xFF2A1038), Color(0xFF6A2A8A), Color(0xFFFF4AB0)],
      12: [Color(0xFFD8CCB4), Color(0xFF7A2CB4), Color(0xFFB4FF50)],
    };
    final pl = pal[k] ?? pal[11]!;
    final base = flashed ? Colors.white : pl[0];
    final sec = flashed ? Colors.white : pl[1];
    final gl = ((k == 1 || k == 12) && b.ph == 2) ? (k == 12 ? const Color(0xFFFF6AE0) : const Color(0xFFFFB347)) : (((k == 1 || k == 12) && b.ph >= 3) ? const Color(0xFFFF4A3A) : pl[2]);
    final glc = C3(gl.red, gl.green, gl.blue);
    c.saveLayer(Rect.fromLTWH(cx - 150, cy - 130, 300, 220), Paint()..color = Color.fromRGBO(255, 255, 255, fade));
    c.translate(shk, 0);
    c.drawOval(Rect.fromCenter(center: Offset(cx, kFloorY), width: 130, height: 12), _fill(const Color(0x66000000)));
    final walk = (b.st == 'idle' || b.st == 'charge') ? math.sin(t / (b.st == 'charge' ? 2.5 : 7)) * 6 : 0.0;
    double hx = cx + face * 24, hy = cy - 8;
    final legP = Paint()..color = base..strokeWidth = 9..strokeCap = StrokeCap.round;
    switch (k) {
      case 1: // الحارس الحجري
        c.drawLine(Offset(cx - 18, cy + 14), Offset(cx - 22 + walk, kFloorY - 2), legP);
        c.drawLine(Offset(cx + 18, cy + 14), Offset(cx + 22 - walk, kFloorY - 2), legP);
        c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(cx, cy - 4), width: 74, height: 60), const Radius.circular(14)), _fill(base));
        c.drawCircle(Offset(cx - 48, cy + 6 + walk * .4), 13, _fill(sec));
        c.drawCircle(Offset(cx + 48, cy + 6 - walk * .4), 13, _fill(sec));
        c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(hx, cy - 34), width: 32, height: 24), const Radius.circular(6)), _fill(sec));
        hy = cy - 34;
        glow(c, cx, cy - 6, 26, glc, .6 + math.sin(t / 8) * .15, add: true);
        c.drawRect(Rect.fromCenter(center: Offset(cx, cy - 6), width: 8, height: 22), Paint()..color = gl.withOpacity(.8)..blendMode = BlendMode.plus);
        break;
      case 3: // وحش الفطر
        c.drawOval(Rect.fromCenter(center: Offset(cx, cy + 6), width: 56, height: 56), _fill(sec == Colors.white ? sec : const Color(0xFFD8C8E8)));
        c.drawPath(
            Path()
              ..moveTo(cx - 62, cy - 12)
              ..quadraticBezierTo(cx, cy - 78, cx + 62, cy - 12)
              ..quadraticBezierTo(cx, cy - 2, cx - 62, cy - 12)
              ..close(),
            _fill(flashed ? Colors.white : pl[1]));
        for (int i = 0; i < 5; i++) {
          c.drawCircle(Offset(cx - 36 + i * 18, cy - 26 - (i % 2) * 8), 5, _fill(const Color(0xFFF0D0FF)));
        }
        c.drawLine(Offset(cx - 14, cy + 30), Offset(cx - 18 + walk, kFloorY - 2), legP..color = const Color(0xFFD8C8E8));
        c.drawLine(Offset(cx + 14, cy + 30), Offset(cx + 18 - walk, kFloorY - 2), legP);
        hx = cx + face * 8;
        hy = cy + 6;
        glow(c, cx, cy - 20, 60, glc, .25, add: true);
        break;
      case 4: // ملك الهياكل
        c.drawLine(Offset(cx - 12, cy + 14), Offset(cx - 16 + walk, kFloorY - 2), legP..strokeWidth = 6);
        c.drawLine(Offset(cx + 12, cy + 14), Offset(cx + 16 - walk, kFloorY - 2), legP);
        c.drawOval(Rect.fromCenter(center: Offset(cx, cy - 2), width: 46, height: 50), _fill(base));
        for (int i = 0; i < 4; i++) {
          c.drawLine(Offset(cx - 18, cy - 14 + i * 9), Offset(cx + 18, cy - 14 + i * 9), Paint()..color = const Color(0xFF3A3A30)..strokeWidth = 2);
        }
        c.drawCircle(Offset(cx, cy - 36), 15, _fill(base));
        c.drawPath(
            Path()
              ..moveTo(cx - 12, cy - 46)
              ..lineTo(cx - 8, cy - 58)
              ..lineTo(cx - 2, cy - 48)
              ..lineTo(cx + 2, cy - 60)
              ..lineTo(cx + 8, cy - 48)
              ..lineTo(cx + 12, cy - 58)
              ..lineTo(cx + 12, cy - 44)
              ..close(),
            _fill(const Color(0xFFE8B83A)));
        c.drawLine(Offset(cx + face * 30, cy - 10), Offset(cx + face * 62, cy - 52 + walk), Paint()..color = const Color(0xFFD8DCE8)..strokeWidth = 4);
        hx = cx;
        hy = cy - 36;
        break;
      case 5: // تنين الحمم
        c.drawPath(
            Path()
              ..moveTo(cx - face * 20, cy - 20)
              ..lineTo(cx - face * 52, cy - 76 + walk)
              ..lineTo(cx - face * 6, cy - 34)
              ..lineTo(cx + face * 28, cy - 70 - walk)
              ..lineTo(cx + face * 22, cy - 22)
              ..close(),
            _fill(sec));
        c.drawLine(Offset(cx - 22, cy + 14), Offset(cx - 26 + walk, kFloorY - 2), legP);
        c.drawLine(Offset(cx + 22, cy + 14), Offset(cx + 26 - walk, kFloorY - 2), legP);
        c.drawOval(Rect.fromCenter(center: Offset(cx - face * 12, cy), width: 84, height: 50), _fill(base));
        c.drawLine(Offset(cx - face * 50, cy + 6), Offset(cx - face * 80, cy + 22), Paint()..color = base..strokeWidth = 8..strokeCap = StrokeCap.round);
        c.drawOval(Rect.fromCenter(center: Offset(cx + face * 32, cy - 14), width: 40, height: 28), _fill(base));
        hx = cx + face * 38;
        hy = cy - 16;
        glow(c, hx + face * 18, hy + 6, 26, glc, b.st == 'rain' ? .9 : .4, add: true);
        break;
      case 6: // العملاق الجليدي
        c.drawLine(Offset(cx - 20, cy + 12), Offset(cx - 24 + walk, kFloorY - 2), legP..strokeWidth = 12);
        c.drawLine(Offset(cx + 20, cy + 12), Offset(cx + 24 - walk, kFloorY - 2), legP);
        c.drawOval(Rect.fromCenter(center: Offset(cx, cy - 8), width: 80, height: 66), _fill(base));
        c.drawCircle(Offset(cx - 52, cy + 4 + walk * .4), 14, _fill(sec));
        c.drawCircle(Offset(cx + 52, cy + 4 - walk * .4), 14, _fill(sec));
        for (int i = -1; i <= 1; i += 2) {
          c.drawPath(
              Path()
                ..moveTo(cx + i * 22, cy - 30)
                ..lineTo(cx + i * 30, cy - 62)
                ..lineTo(cx + i * 38, cy - 28)
                ..close(),
              _fill(sec));
        }
        c.drawCircle(Offset(cx + face * 10, cy - 44), 17, _fill(base));
        hx = cx + face * 10;
        hy = cy - 44;
        glow(c, cx, cy - 8, 70, glc, .15, add: true);
        break;
      case 7: // حارس المقبرة
        c.drawPath(
            Path()
              ..moveTo(cx, cy - 52)
              ..quadraticBezierTo(cx + 42, cy - 20, cx + 54, kFloorY - 2)
              ..lineTo(cx - 54, kFloorY - 2)
              ..quadraticBezierTo(cx - 42, cy - 20, cx, cy - 52)
              ..close(),
            _fill(base));
        c.drawCircle(Offset(cx + face * 6, cy - 40), 14, _fill(const Color(0xFF0A0A12)));
        c.drawLine(Offset(cx + face * 38, cy - 60), Offset(cx + face * 38, cy + 20), Paint()..color = const Color(0xFF6A5A3A)..strokeWidth = 3);
        c.drawArc(Rect.fromLTWH(cx + face * 38 - (face > 0 ? 0 : 26), cy - 68, 26, 26), face > 0 ? -2.6 : -.5, 2.2, false, Paint()..color = const Color(0xFFD8DCE8)..style = PaintingStyle.stroke..strokeWidth = 3);
        hx = cx + face * 6;
        hy = cy - 40;
        glow(c, cx, cy, 70, glc, .18, add: true);
        break;
      case 8: // الأسد الحجري
        c.drawLine(Offset(cx - 22, cy + 14), Offset(cx - 26 + walk, kFloorY - 2), legP);
        c.drawLine(Offset(cx + 22, cy + 14), Offset(cx + 26 - walk, kFloorY - 2), legP);
        c.drawOval(Rect.fromCenter(center: Offset(cx - face * 16, cy + 2), width: 76, height: 46), _fill(base));
        c.drawCircle(Offset(cx + face * 26, cy - 8), 30, _fill(sec));
        c.drawCircle(Offset(cx + face * 28, cy - 6), 18, _fill(base));
        hx = cx + face * 28;
        hy = cy - 6;
        glow(c, hx, hy, 34, glc, .25, add: true);
        break;
      case 9: // وحش الكريستال
        for (int i = -3; i <= 3; i++) {
          c.drawPath(
              Path()
                ..moveTo(cx + i * 14 - 8, cy + 20)
                ..lineTo(cx + i * 12, cy - 28 - (3 - i.abs()) * 14)
                ..lineTo(cx + i * 14 + 8, cy + 20)
                ..close(),
              _fill(i.isEven ? base : sec));
        }
        c.drawLine(Offset(cx - 18, cy + 16), Offset(cx - 22 + walk, kFloorY - 2), legP);
        c.drawLine(Offset(cx + 18, cy + 16), Offset(cx + 22 - walk, kFloorY - 2), legP);
        glow(c, cx, cy - 6, 44, glc, .6 + math.sin(t / 7) * .15, add: true);
        hx = cx + face * 8;
        hy = cy - 4;
        break;
      case 10: // ملك الظلام
        c.drawPath(
            Path()
              ..moveTo(cx, cy - 56)
              ..quadraticBezierTo(cx + 38, cy - 10, cx + 46, kFloorY - 2)
              ..lineTo(cx - 46, kFloorY - 2)
              ..quadraticBezierTo(cx - 38, cy - 10, cx, cy - 56)
              ..close(),
            _fill(base));
        c.drawPath(
            Path()
              ..moveTo(cx - 14, cy - 56)
              ..lineTo(cx - 10, cy - 72)
              ..lineTo(cx - 3, cy - 60)
              ..lineTo(cx, cy - 76)
              ..lineTo(cx + 3, cy - 60)
              ..lineTo(cx + 10, cy - 72)
              ..lineTo(cx + 14, cy - 56)
              ..close(),
            _fill(const Color(0xFFB84AFF)));
        for (int i = 0; i < 4; i++) {
          glow(c, cx + math.sin(t / 20 + i * 1.6) * 36, kFloorY - 8 - i * 8, 18, glc, .3, add: true);
        }
        hx = cx + face * 4;
        hy = cy - 44;
        break;
      case 12: // ملك الفطر السام: فطر عملاق بثلاث مراحل قتالية
        {
          // جذور تتحرك كأرجل
          final rp = Paint()
            ..color = (flashed ? Colors.white : const Color(0xFF5A2E6E))
            ..strokeWidth = 7
            ..strokeCap = StrokeCap.round
            ..style = PaintingStyle.stroke;
          for (int i = 0; i < 4; i++) {
            final sx = cx - 30 + i * 20.0;
            final wob = math.sin(t / 7 + i * 1.6) * (b.st == 'idle' || b.st == 'charge' ? 6 : 2);
            final rpath = Path()
              ..moveTo(sx, cy + 18)
              ..quadraticBezierTo(sx + (i.isEven ? -14 : 14) + wob, cy + 34, sx + (i.isEven ? -20 : 20) + wob, kFloorY - 2);
            c.drawPath(rpath, rp);
          }
          // الساق (الجذع)
          c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(cx, cy + 2), width: 58, height: 52), const Radius.circular(18)), _fill(base));
          c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(cx, cy + 2), width: 58, height: 52), const Radius.circular(18)), Paint()..color = const Color(0x55000000)..style = PaintingStyle.stroke..strokeWidth = 1.4);
          // القبعة العملاقة
          final capTop = cy - 88 - (b.st == 'spore' ? math.sin(b.t / 3.0) * 4 : 0.0);
          final capP = Path()
            ..moveTo(cx - 78, cy - 14)
            ..quadraticBezierTo(cx - 74, capTop, cx, capTop)
            ..quadraticBezierTo(cx + 74, capTop, cx + 78, cy - 14)
            ..quadraticBezierTo(cx, cy - 2, cx - 78, cy - 14)
            ..close();
          c.drawPath(capP, Paint()..shader = ui.Gradient.linear(Offset(cx, capTop), Offset(cx, cy - 8), [flashed ? Colors.white : Color.lerp(sec, Colors.white, .22)!, sec]));
          c.drawPath(capP, Paint()..color = const Color(0x66000000)..style = PaintingStyle.stroke..strokeWidth = 1.6);
          // خياشيم تحت القبعة
          for (int i = -5; i <= 5; i++) {
            c.drawLine(Offset(cx + i * 13.0, cy - 12), Offset(cx + i * 11.0, cy - 5), Paint()..color = const Color(0x55000000)..strokeWidth = 1.2);
          }
          // بقع مضيئة
          for (int i = 0; i < 6; i++) {
            final sx = cx - 50 + i * 20.0;
            final sy = capTop + 22 + (i % 3) * 14.0;
            c.drawCircle(Offset(sx, sy), 6.0 - (i % 3), _fill(const Color(0xFFE8D0FF)));
          }
          // الكيس المضيء = نقطة الضعف (يشتعل بعد كل هجوم أثناء التعثّر)
          final sacOn = stun;
          final sacX = cx + math.sin(t / 30.0) * 3;
          final sacY = capTop + 12;
          glow(c, sacX, sacY, sacOn ? 44 : 26, glc, sacOn ? .85 : .4 + math.sin(t / 10.0) * .1, add: true);
          c.drawOval(Rect.fromCenter(center: Offset(sacX, sacY), width: 22, height: 16), _fill(sacOn ? const Color(0xFFFFF6A0) : Color.fromRGBO(glc.r, glc.g, glc.b, 1)));
          c.drawOval(Rect.fromCenter(center: Offset(sacX - 3, sacY - 2), width: 7, height: 5), Paint()..color = const Color(0x99FFFFFF));
          // قرون الشوك على القبعة في المرحلة الثالثة
          if (b.ph >= 3) {
            for (int i = -2; i <= 2; i++) {
              c.drawPath(
                  Path()
                    ..moveTo(cx + i * 22.0 - 6, capTop + 8 + i.abs() * 6)
                    ..lineTo(cx + i * 22.0, capTop - 12 + i.abs() * 6)
                    ..lineTo(cx + i * 22.0 + 6, capTop + 8 + i.abs() * 6)
                    ..close(),
                  _fill(const Color(0xFFFF4A3A)));
            }
          }
          // أبواغ تتصاعد
          for (int i = 0; i < 5; i++) {
            final ph = (t / 60.0 + i * .21) % 1.0;
            c.drawCircle(Offset(cx - 60 + i * 30.0 + math.sin(t / 15.0 + i) * 6, capTop + 10 - ph * 40), 2.2 * (1 - ph), Paint()..color = Color.fromRGBO(gl.red, gl.green, gl.blue, .8 * (1 - ph))..blendMode = BlendMode.plus);
          }
          hx = cx + face * 4;
          hy = cy + 4;
          glow(c, cx, cy - 30, 90, glc, .2, add: true);
          break;
        }
      default: // الزعيم الأخير
        c.drawLine(Offset(cx - 20, cy + 14), Offset(cx - 24 + walk, kFloorY - 2), legP);
        c.drawLine(Offset(cx + 20, cy + 14), Offset(cx + 24 - walk, kFloorY - 2), legP);
        c.drawOval(Rect.fromCenter(center: Offset(cx, cy - 6), width: 84, height: 64), _fill(base));
        for (int i = 0; i < 3; i++) {
          c.drawArc(Rect.fromCenter(center: Offset(cx, cy - 6), width: 100 + i * 24, height: 76 + i * 20), t / (14.0 + i * 6) + i * 2, 1.7, false, Paint()..color = gl.withOpacity(.7)..style = PaintingStyle.stroke..strokeWidth = 2..blendMode = BlendMode.plus);
        }
        c.drawPath(
            Path()
              ..moveTo(cx - 16, cy - 36)
              ..lineTo(cx - 12, cy - 54)
              ..lineTo(cx - 4, cy - 40)
              ..lineTo(cx, cy - 58)
              ..lineTo(cx + 4, cy - 40)
              ..lineTo(cx + 12, cy - 54)
              ..lineTo(cx + 16, cy - 36)
              ..close(),
            _fill(const Color(0xFFFF4AB0)));
        hx = cx + face * 8;
        hy = cy - 14;
        glow(c, cx, cy - 6, 80, glc, .22, add: true);
    }
    // العيون
    final ec = b.enraged ? const C3(255, 60, 40) : glc;
    for (int i = 0; i < 2; i++) {
      final ex2 = hx + face * 5 + (i - .5) * 9;
      glow(c, ex2, hy, 8, ec, .9, add: true);
      c.drawCircle(Offset(ex2, hy), 2.2, _fill(Color.fromRGBO(ec.r, ec.g, ec.b, 1)));
    }
    if (b.st == 'rain' || b.st == 'ring' || b.st == 'spore' || b.st == 'cloud') glow(c, cx, cy - 10, 60 + math.sin(t / 3) * 8, glc, .35, add: true);
    if (b.st == 'charge' && b.t < 32) glow(c, cx, cy, 70, const C3(255, 60, 40), .15 + (b.t % 8) * .03, add: true);
    if (b.enraged && b.st != 'dead') glow(c, cx, cy, 80, const C3(255, 50, 30), .18 + math.sin(t / 6) * .05, add: true);
    if (stun) {
      for (int i = 0; i < 4; i++) {
        final ang = t / 8 + i * math.pi / 2;
        c.drawCircle(Offset(hx + math.cos(ang) * 16, hy - 24 + math.sin(ang) * 5), 2.2, Paint()..color = const Color(0xFFFFE27A)..blendMode = BlendMode.plus);
      }
    }
    c.restore();
  }

  void _projs(Canvas c) {
    final cam = e.cam;
    final g3 = cfg.world == 3;
    for (final q in e.projs) {
      final x = q.x - cam;
      if (x < -40 || x > vw + 40) continue;
      if (q.kind == 4) {
        // سحابة سامة: تحذير شفاف ثم ضرر
        final warn = q.l > 200;
        final al = warn ? .18 : .55;
        for (int i = 0; i < 6; i++) {
          final bx = x - 18 + i * 7.2 + math.sin(e.t / 9 + i * 2) * 4;
          final by = q.y - 4 - (i % 3) * 8 - math.sin(e.t / 12 + i) * 3;
          c.drawCircle(Offset(bx, by), warn ? 7 : 12, Paint()..color = Color.fromRGBO(150, 255, 90, al));
        }
        glow(c, x, q.y - 6, 40, const C3(160, 255, 90), warn ? .15 : .4, add: true);
        continue;
      }
      if (q.kind == 3) {
        glow(c, x, q.y, 16, const C3(170, 255, 90), .8, add: true);
        c.drawCircle(Offset(x, q.y), 4, _fill(const Color(0xFFD8FF9A)));
        c.drawCircle(Offset(x, q.y), 2, _fill(const Color(0xFFFFFFFF)));
        c.drawLine(Offset(x, q.y), Offset(x - q.vx * 4, q.y - q.vy * 4), Paint()..color = const Color(0x88B4FF50)..strokeWidth = 1.6);
      } else if (q.kind == 2) {
        glow(c, x, q.y, 14, g3 ? const C3(170, 255, 90) : const C3(255, 150, 70), .8, add: true);
        c.drawCircle(Offset(x, q.y), 3.6, _fill(g3 ? const Color(0xFFD8FF9A) : const Color(0xFFFFE0A0)));
        c.drawCircle(Offset(x, q.y), 2, _fill(const Color(0xFFFFFFFF)));
        c.drawLine(Offset(x, q.y), Offset(x - q.vx * 4, q.y - q.vy * 4), Paint()..color = (g3 ? const Color(0x88B4FF50) : const Color(0x88FFB347))..strokeWidth = 1.6);
      } else if (q.kind == 0) {
        glow(c, x, q.y, 12, const C3(200, 255, 190), .7, add: true);
        c.drawCircle(Offset(x, q.y), 3.4, _fill(const Color(0xFFE8FFE0)));
        c.drawLine(Offset(x, q.y), Offset(x - q.vx * 4, q.y - q.vy * 4), Paint()..color = const Color(0x88FFFFFF)..strokeWidth = 1);
      } else {
        glow(c, x, q.y + 6, 16, g3 ? const C3(150, 255, 80) : const C3(200, 120, 255), .6, add: true);
        c.drawOval(Rect.fromCenter(center: Offset(x, q.y + 6), width: 10, height: 16), Paint()..color = (g3 ? const Color(0xCCC8FF90) : const Color(0xCCE6B8FF))..blendMode = BlendMode.plus);
      }
    }
  }

  void _lighting(Canvas c) {
    final cam = e.cam, t = e.t;
    c.saveLayer(Rect.fromLTWH(-12, -12, vw + 24, kH + 24), Paint());
    c.drawRect(Rect.fromLTWH(-12, -12, vw + 24, kH + 24), _fill(Color.fromRGBO(3, 6, 16, th.dark)));
    void hole(double x, double y, double r, double s) {
      if (x < -r || x > vw + r) return;
      c.drawCircle(Offset(x, y), r, Paint()..blendMode = BlendMode.dstOut..shader = ui.Gradient.radial(Offset(x, y), r, [Color.fromRGBO(255, 255, 255, s), const Color(0x00FFFFFF)]));
    }
    hole(e.p.x - cam + 7, e.p.y + 12, 200 + math.sin(t / 12) * 6, .97);
    for (final o in a.props) {
      if (o.glw == null || o.layer == 0) continue;
      hole(o.x - cam, kFloorY - o.h * .5, o.h * 2.2 + 30, .9);
    }
    for (final m in e.embers) {
      if (!m.taken) hole(m.x - cam, m.y, 40, .9);
    }
    for (final ch in e.chests) {
      if (!ch.open) hole(ch.x - cam + 10, ch.y + 6, 44, .9);
    }
    hole(cfg.goalX - cam, cfg.goalY + 25, 240, e.goalOpen ? 1 : .5);
    for (final en in e.en) {
      if (en.hp > 0) hole(en.x - cam + 9, en.y + 6, 36, .8);
    }
    final b = e.boss;
    if (b != null && b.st != 'sleep') hole(b.x + b.w / 2 - cam, b.y + 28, 110, .95);
    for (final q in e.projs) {
      hole(q.x - cam, q.y, 28, .9);
    }
    for (final bb in e.bubs) {
      if (bb.alive) hole(bb.x - cam, bb.y, 38, .85);
    }
    c.restore();
  }

  void _warmGlows(Canvas c) {
    final cam = e.cam, t = e.t;
    for (final o in a.props) {
      final px = o.x - cam;
      if (px < -40 || px > vw + 40) continue;
      if (o.k == 'torch') {
        final fy = kFloorY - o.h + 2;
        final fl = math.sin(t / 3 + o.x) * 1.2;
        glow(c, px, fy - 4, 46, const C3(255, 150, 60), .55 + math.sin(t / 5 + o.x) * .1, add: true);
        final f = Path()
          ..moveTo(px - 4, fy)
          ..quadraticBezierTo(px - 5 + fl, fy - 8, px + fl, fy - 15 - fl.abs())
          ..quadraticBezierTo(px + 5 + fl, fy - 8, px + 4, fy)
          ..close();
        c.drawPath(f, Paint()..color = const Color(0xCCFF9A3C)..blendMode = BlendMode.plus);
        c.drawOval(Rect.fromCenter(center: Offset(px, fy - 4), width: 4, height: 8), Paint()..color = const Color(0xCCFFEBB0)..blendMode = BlendMode.plus);
      } else if (o.k == 'lantern') {
        glow(c, px - 4, kFloorY - o.h * .3, 22, const C3(255, 190, 90), .5 + math.sin(t / 9 + o.x) * .08, add: true);
      }
    }
    final p = e.p;
    final px = p.x - cam + 7;
    glow(c, px, p.y + 14, 120, const C3(255, 170, 70), .42 + math.sin(t / 12) * .05, add: true);
  }

  void _player(Canvas c) {
    final p = e.p, t = e.t;
    final px = p.x - e.cam, py = p.y;
    if (e.phase == Phase.dead) return;
    if (p.inv > 0 && t % 6 < 3) return;
    const ch = 39.3;
    const k = ch / 448.0;
    const dw = 400 * k;
    Offset pv(double x, double y) => Offset(-dw / 2 + x * k, -ch + y * k);
    final shN = pv(170.4, 156.3), shF = pv(246.1, 156.3);
    final hipN = pv(174.8, 272.9), hipF = pv(243.6, 272.9);
    const legScale = 1.0;
    const drop = (448 - 272.9) * k * (1 - legScale);
    final paint = Paint()..filterQuality = FilterQuality.medium;
    void layer(String n, {double ang = 0, Offset piv = Offset.zero, double dy = 0, double sy = 1}) {
      final img = a.sp[n]!;
      c.save();
      c.translate(0, dy);
      if (ang != 0 || sy != 1) {
        c.translate(piv.dx, piv.dy);
        c.rotate(ang);
        c.scale(1, sy);
        c.translate(-piv.dx, -piv.dy);
      }
      c.drawImageRect(img, Rect.fromLTWH(0, 0, img.width.toDouble(), img.height.toDouble()), const Rect.fromLTWH(-dw / 2, -ch, dw, ch), paint);
      c.restore();
    }

    c.save();
    c.translate(px + 7, py + 22);
    c.scale(p.f.toDouble() * (1 + p.sq * .5), 1 - p.sq);
    c.rotate(p.lean);
    // ظل خفيف تحت القدمين
    c.drawOval(Rect.fromCenter(center: const Offset(0, 0.5), width: 14, height: 3), _fill(const Color(0x55000000)));
    layer('hero_armF', ang: p.aF, piv: shF, dy: p.bob + drop);
    layer('hero_legF', ang: p.lF, piv: hipF, dy: drop, sy: legScale);
    layer('hero_legN', ang: p.lN, piv: hipN, dy: drop, sy: legScale);
    layer('hero_body', dy: p.bob + drop);
    layer('hero_armN', ang: p.aN, piv: shN, dy: p.bob + drop);
    layer('hero_weapon', ang: p.aN, piv: shN, dy: p.bob + drop);
    // الفانوس في اليد
    final hand = Offset(shF.dx - math.sin(p.aF) * 12.0, shF.dy + p.bob + drop + math.cos(p.aF) * 12.0);
    final lp = hand + const Offset(1.6, 1.8);
    c.drawLine(hand, lp, Paint()..color = const Color(0xFF1A1424)..strokeWidth = 0.8);
    glow(c, lp.dx, lp.dy + 1, 10, const C3(255, 190, 90), .9, add: true);
    c.drawRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: lp + const Offset(0, 1.5), width: 3.4, height: 4.2), const Radius.circular(1)), _fill(const Color(0xFFFFB347)));
    c.drawCircle(lp + const Offset(0, 1.5), 0.9, _fill(const Color(0xFFFFF4D2)));
    c.restore();
    // موجة الصدمة عند ضرب المطرقة
    if (p.atk > 7 && p.atk < 13) {
      final k2 = (13 - p.atk) / 6;
      final ix = px + 7 + p.f * 24;
      glow(c, ix, py + 20, 14 + k2 * 22, const C3(150, 230, 255), .9 * (1 - k2), add: true);
      c.drawOval(Rect.fromCenter(center: Offset(ix, py + 21), width: 20 + k2 * 50, height: 6 + k2 * 10),
          Paint()..color = Color.fromRGBO(190, 240, 255, .8 * (1 - k2))..style = PaintingStyle.stroke..strokeWidth = 1.5..blendMode = BlendMode.plus);
    }
  }

  void _hud(Canvas c) {
    final p = e.p, t = e.t;
    if (e.kdoors.any((k) => k.taken && !k.open)) {
      glow(c, 22, 46, 16, const C3(255, 220, 100), .6, add: true);
      c.drawCircle(const Offset(18, 46), 4, Paint()..color = const Color(0xFFFFD36A)..style = PaintingStyle.stroke..strokeWidth = 2);
      c.drawLine(const Offset(22, 46), const Offset(34, 46), Paint()..color = const Color(0xFFFFD36A)..strokeWidth = 2);
      c.drawLine(const Offset(30, 46), const Offset(30, 50), Paint()..color = const Color(0xFFFFD36A)..strokeWidth = 2);
    }
    for (int i = 0; i < e.maxHp; i++) {
      final on = i < p.hp;
      final x = 20.0 + i * 19, y = 24.0;
      if (on) glow(c, x, y, 13, const C3(255, 170, 70), .6, add: true);
      c.drawCircle(Offset(x, y), 6.5, Paint()..shader = ui.Gradient.radial(Offset(x - 1, y - 1), 8, on ? const [Color(0xFFFFF1C2), Color(0xFFFF9A3C)] : const [Color(0xFF3A4156), Color(0xFF1F2433)]));
      c.drawCircle(Offset(x, y), 6.5, Paint()..color = (on ? const Color(0x88FFE3A8) : const Color(0x44556080))..style = PaintingStyle.stroke..strokeWidth = 1);
    }
    final txt = '${e.collected}/${e.totalEmbers}';
    final tp = TextPainter(text: TextSpan(text: txt, style: const TextStyle(color: Color(0xFFFFE3A8), fontSize: 14, fontWeight: FontWeight.w800)), textDirection: TextDirection.ltr)..layout();
    tp.paint(c, Offset(vw - 14 - tp.width, 15));
    final ix = vw - 14 - tp.width - 14, iy = 24 + math.sin(t / 15) * 1.0;
    glow(c, ix, iy, 12, const C3(255, 170, 70), .6, add: true);
    c.drawCircle(Offset(ix, iy), 4.2, _fill(const Color(0xFFFFD27A)));
    final b = e.boss;
    if (b != null && b.st != 'sleep') {
      if (_bossName != b.name) {
        _bossName = b.name;
        _bossTp = TextPainter(text: TextSpan(text: b.name, style: const TextStyle(color: Color(0xFFFFE3A8), fontSize: 13, fontWeight: FontWeight.w800)), textDirection: TextDirection.rtl)..layout();
      }
      final w = math.min(240.0, vw - 60), x0 = (vw - w) / 2, y0 = 54.0;
      _bossTp?.paint(c, Offset((vw - _bossTp!.width) / 2, y0 - 18));
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x0 - 2, y0 - 2, w + 4, 12), const Radius.circular(6)), _fill(const Color(0xAA000000)));
      final frac = (b.hp / b.maxHp).clamp(0.0, 1.0).toDouble();
      if (frac > 0) {
        c.drawRRect(
            RRect.fromRectAndRadius(Rect.fromLTWH(x0, y0, w * frac, 8), const Radius.circular(4)),
            Paint()..shader = ui.Gradient.linear(Offset(x0, y0), Offset(x0 + w, y0), b.enraged ? const [Color(0xFFFF3A2A), Color(0xFFFF8A3C)] : const [Color(0xFFB84AFF), Color(0xFFFF6AB0)]));
      }
      c.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x0 - 2, y0 - 2, w + 4, 12), const Radius.circular(6)), Paint()..color = const Color(0x88FFE3A8)..style = PaintingStyle.stroke..strokeWidth = 1);
    }
  }
}
